import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "npm:resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface EnquiryRequest {
  name: string;
  email: string;
  phone?: string;
  service: string;
  destination?: string;
  message: string;
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { name, email, phone, service, destination, message }: EnquiryRequest = await req.json();

    console.log("Processing enquiry:", { name, email, service, destination });

    const emailContent = `
      <h2>New Enquiry from VR Holidays</h2>
      <p><strong>Name:</strong> ${name}</p>
      <p><strong>Email:</strong> ${email}</p>
      ${phone ? `<p><strong>Phone:</strong> ${phone}</p>` : ''}
      <p><strong>Service:</strong> ${service}</p>
      ${destination ? `<p><strong>Destination:</strong> ${destination}</p>` : ''}
      <p><strong>Message:</strong></p>
      <p>${message}</p>
    `;

    const emailResponse = await resend.emails.send({
      from: "VR Holidays <onboarding@resend.dev>",
      to: ["trichy@vrholidays.co.in"],
      subject: `New Enquiry: ${service}${destination ? ` - ${destination}` : ''}`,
      html: emailContent,
    });

    console.log("Email sent successfully:", emailResponse);

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders,
      },
    });
  } catch (error: any) {
    console.error("Error in send-enquiry function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
