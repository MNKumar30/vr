import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MapPin, Phone, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import DestinationDetailsDialog from "@/components/DestinationDetailsDialog";
import EnquiryDialog from "@/components/EnquiryDialog";

// Import destination images
import baliRiceTerraces from "@/assets/destinations/bali-rice-terraces.jpg";
import dubaiBurjKhalifa from "@/assets/destinations/dubai-burj-khalifa.jpg";
import maldivesResort from "@/assets/destinations/maldives-resort.jpg";
import parisEiffel from "@/assets/destinations/paris-eiffel.jpg";
import singaporeMarina from "@/assets/destinations/singapore-marina.jpg";
import japanFuji from "@/assets/destinations/japan-fuji.jpg";
import cambodiaAngkor from "@/assets/destinations/cambodia-angkor.jpg";
import hongkongSkyline from "@/assets/destinations/hongkong-skyline.jpg";
import indonesiaBorobudur from "@/assets/destinations/indonesia-borobudur.jpg";
import koreaPalace from "@/assets/destinations/korea-palace.jpg";
import philippinesElnido from "@/assets/destinations/philippines-elnido.jpg";
import chinaWall from "@/assets/destinations/china-wall.jpg";
import vietnamHalong from "@/assets/destinations/vietnam-halong.jpg";
import thailandPalace from "@/assets/destinations/thailand-palace.jpg";
import abudhabiMosque from "@/assets/destinations/abudhabi-mosque.jpg";
import srilankaSigiriya from "@/assets/destinations/srilanka-sigiriya.jpg";
import switzerlandAlps from "@/assets/destinations/switzerland-alps.jpg";
import italyVenice from "@/assets/destinations/italy-venice.jpg";
import spainSagrada from "@/assets/destinations/spain-sagrada.jpg";
import franceProvence from "@/assets/destinations/france-provence.jpg";
import icelandAurora from "@/assets/destinations/iceland-aurora.jpg";
import russiaRedSquare from "@/assets/destinations/russia-redsquare.jpg";
import ukBigBen from "@/assets/destinations/uk-bigben.jpg";
import londonTower from "@/assets/destinations/london-tower.jpg";
import canadaNiagara from "@/assets/destinations/canada-niagara.jpg";
import usaGrandCanyon from "@/assets/destinations/usa-grandcanyon.jpg";
import northamericaStatue from "@/assets/destinations/northamerica-statue.jpg";
import centralamericaMayan from "@/assets/destinations/centralamerica-mayan.jpg";
import southamericaMachu from "@/assets/destinations/southamerica-machu.jpg";
import malaysiaTowers from "@/assets/destinations/malaysia-towers.jpg";
import internationalToursImage from "@/assets/international-tours.jpg";

const InternationalToursPage = () => {
  const [selectedDestination, setSelectedDestination] = useState<any>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [enquiryOpen, setEnquiryOpen] = useState(false);
  const [enquiryContext, setEnquiryContext] = useState({ service: "", destination: "" });

  const destinationsData = {
    asia: [
      { 
        name: "Japan", 
        image: japanFuji, 
        description: "Land of rising sun with ancient temples",
        attractions: [
          { name: "Mount Fuji", description: "Iconic sacred mountain" },
          { name: "Tokyo Tower", description: "Modern city landmark" },
          { name: "Kyoto Temples", description: "Ancient Zen gardens" },
          { name: "Cherry Blossoms", description: "Spring flower viewing" },
          { name: "Osaka Castle", description: "Historic fortress" }
        ]
      },
      { 
        name: "Thailand", 
        image: thailandPalace, 
        description: "Land of smiles with golden temples",
        attractions: [
          { name: "Grand Palace", description: "Bangkok royal residence" },
          { name: "Phi Phi Islands", description: "Beautiful beaches" },
          { name: "Floating Markets", description: "Traditional markets on water" },
          { name: "Wat Pho Temple", description: "Reclining Buddha" },
          { name: "Pattaya Beach", description: "Coastal paradise" }
        ]
      },
      { 
        name: "Singapore", 
        image: singaporeMarina, 
        description: "Garden city with futuristic architecture",
        attractions: [
          { name: "Marina Bay Sands", description: "Iconic rooftop infinity pool" },
          { name: "Gardens by the Bay", description: "Futuristic garden with Supertrees" },
          { name: "Sentosa Island", description: "Beach resort and theme parks" },
          { name: "Universal Studios", description: "Movie theme park" },
          { name: "Merlion Park", description: "Singapore's symbol" }
        ]
      },
      { 
        name: "Cambodia", 
        image: cambodiaAngkor, 
        description: "Ancient temples and rich history",
        attractions: [
          { name: "Angkor Wat", description: "Largest religious monument" },
          { name: "Bayon Temple", description: "Smiling stone faces" },
          { name: "Ta Prohm", description: "Temple in the jungle" },
          { name: "Tonle Sap", description: "Floating villages" },
          { name: "Royal Palace", description: "Phnom Penh landmark" }
        ]
      },
      { 
        name: "Hong Kong", 
        image: hongkongSkyline, 
        description: "Dynamic city with stunning skyline",
        attractions: [
          { name: "Victoria Peak", description: "Panoramic city views" },
          { name: "Tsim Sha Tsui", description: "Shopping district" },
          { name: "Disneyland", description: "Theme park" },
          { name: "Big Buddha", description: "Lantau Island statue" },
          { name: "Star Ferry", description: "Harbor cruise" }
        ]
      },
      { 
        name: "Indonesia", 
        image: indonesiaBorobudur, 
        description: "Island paradise with ancient temples",
        attractions: [
          { name: "Borobudur", description: "Buddhist temple complex" },
          { name: "Komodo Island", description: "Dragons and beaches" },
          { name: "Bromo Volcano", description: "Sunrise trek" },
          { name: "Yogyakarta", description: "Cultural heart" },
          { name: "Raja Ampat", description: "Diving paradise" }
        ]
      },
      { 
        name: "South Korea", 
        image: koreaPalace, 
        description: "Modern cities and traditional culture",
        attractions: [
          { name: "Gyeongbokgung Palace", description: "Royal palace in Seoul" },
          { name: "N Seoul Tower", description: "City observation deck" },
          { name: "Jeju Island", description: "Volcanic island beaches" },
          { name: "Bukchon Hanok", description: "Traditional village" },
          { name: "DMZ", description: "Korean border tour" }
        ]
      },
      { 
        name: "Philippines", 
        image: philippinesElnido, 
        description: "Tropical islands and pristine beaches",
        attractions: [
          { name: "El Nido", description: "Lagoons and limestone cliffs" },
          { name: "Boracay", description: "White sand beaches" },
          { name: "Chocolate Hills", description: "Unique geological formations" },
          { name: "Manila", description: "Historic Intramuros" },
          { name: "Taal Volcano", description: "Lake within a volcano" }
        ]
      },
      { 
        name: "China", 
        image: chinaWall, 
        description: "Ancient wonders and modern marvels",
        attractions: [
          { name: "Great Wall", description: "Ancient fortification" },
          { name: "Forbidden City", description: "Imperial palace" },
          { name: "Terracotta Army", description: "Archaeological wonder" },
          { name: "Li River", description: "Scenic karst landscape" },
          { name: "Shanghai Bund", description: "Historic waterfront" }
        ]
      },
      { 
        name: "Malaysia", 
        image: malaysiaTowers, 
        description: "Tropical paradise with modern cities",
        attractions: [
          { name: "Petronas Towers", description: "Twin skyscrapers" },
          { name: "Batu Caves", description: "Hindu temple in caves" },
          { name: "Langkawi", description: "Island beaches" },
          { name: "Penang", description: "Food capital" },
          { name: "Cameron Highlands", description: "Tea plantations" }
        ]
      },
      { 
        name: "Bali", 
        image: baliRiceTerraces, 
        description: "Island of Gods with stunning nature",
        attractions: [
          { name: "Ubud Rice Terraces", description: "Scenic paddy fields" },
          { name: "Tanah Lot", description: "Sea temple" },
          { name: "Uluwatu", description: "Clifftop temple" },
          { name: "Seminyak Beach", description: "Beach clubs" },
          { name: "Mount Batur", description: "Sunrise trek" }
        ]
      },
      { 
        name: "Vietnam", 
        image: vietnamHalong, 
        description: "Ha Long Bay and vibrant cities",
        attractions: [
          { name: "Ha Long Bay", description: "UNESCO bay cruise" },
          { name: "Hoi An", description: "Ancient town lanterns" },
          { name: "Cu Chi Tunnels", description: "War history" },
          { name: "Mekong Delta", description: "River tours" },
          { name: "Hanoi Old Quarter", description: "Street food paradise" }
        ]
      }
    ],
    middleEast: [
      { 
        name: "UAE", 
        image: dubaiBurjKhalifa, 
        description: "Modern luxury in the desert",
        attractions: [
          { name: "Burj Khalifa", description: "Tallest building" },
          { name: "Dubai Mall", description: "Mega shopping destination" },
          { name: "Desert Safari", description: "Dune adventures" },
          { name: "Palm Jumeirah", description: "Iconic island" },
          { name: "Dubai Marina", description: "Waterfront lifestyle" }
        ]
      },
      { 
        name: "Dubai", 
        image: dubaiBurjKhalifa, 
        description: "City of superlatives and luxury",
        attractions: [
          { name: "Burj Khalifa", description: "World's tallest tower" },
          { name: "Gold Souk", description: "Traditional markets" },
          { name: "Ski Dubai", description: "Indoor skiing" },
          { name: "Miracle Garden", description: "Flower paradise" },
          { name: "Dubai Creek", description: "Historic waterway" }
        ]
      },
      { 
        name: "Abu Dhabi", 
        image: abudhabiMosque, 
        description: "Capital city with grand mosques",
        attractions: [
          { name: "Sheikh Zayed Mosque", description: "Stunning white mosque" },
          { name: "Louvre Abu Dhabi", description: "Art museum" },
          { name: "Ferrari World", description: "Theme park" },
          { name: "Corniche", description: "Beachfront promenade" },
          { name: "Qasr Al Watan", description: "Presidential palace" }
        ]
      }
    ],
    island: [
      { 
        name: "Sri Lanka", 
        image: srilankaSigiriya, 
        description: "Pearl of the Indian Ocean",
        attractions: [
          { name: "Sigiriya Rock", description: "Ancient rock fortress" },
          { name: "Kandy Temple", description: "Sacred tooth relic" },
          { name: "Ella", description: "Hill country tea estates" },
          { name: "Galle Fort", description: "Dutch colonial fort" },
          { name: "Yala Safari", description: "Wildlife leopards" }
        ]
      },
      { 
        name: "Maldives", 
        image: maldivesResort, 
        description: "Tropical paradise with crystal waters",
        attractions: [
          { name: "Overwater Villas", description: "Luxury bungalows on stilts" },
          { name: "Coral Reefs", description: "Snorkeling and diving" },
          { name: "Private Islands", description: "Exclusive resort experiences" },
          { name: "Bioluminescent Beach", description: "Glowing plankton at night" },
          { name: "Underwater Restaurant", description: "Dining beneath the sea" }
        ]
      }
    ],
    europe: [
      { 
        name: "France", 
        image: franceProvence, 
        description: "Romance, art, and lavender fields",
        attractions: [
          { name: "Eiffel Tower", description: "Paris landmark" },
          { name: "Louvre Museum", description: "World-class art" },
          { name: "French Riviera", description: "Mediterranean coast" },
          { name: "Mont Saint-Michel", description: "Island abbey" },
          { name: "Versailles", description: "Palace of Kings" }
        ]
      },
      { 
        name: "Iceland", 
        image: icelandAurora, 
        description: "Land of fire and ice",
        attractions: [
          { name: "Northern Lights", description: "Aurora borealis" },
          { name: "Blue Lagoon", description: "Geothermal spa" },
          { name: "Golden Circle", description: "Scenic route" },
          { name: "Waterfalls", description: "Stunning cascades" },
          { name: "Glaciers", description: "Ice formations" }
        ]
      },
      { 
        name: "Russia", 
        image: russiaRedSquare, 
        description: "Historic grandeur and culture",
        attractions: [
          { name: "Red Square", description: "Moscow's heart" },
          { name: "Kremlin", description: "Historic fortress" },
          { name: "St. Basil's Cathedral", description: "Colorful domes" },
          { name: "Hermitage Museum", description: "Art collection" },
          { name: "Trans-Siberian Railway", description: "Epic train journey" }
        ]
      },
      { 
        name: "Spain", 
        image: spainSagrada, 
        description: "Vibrant culture and beaches",
        attractions: [
          { name: "Sagrada Familia", description: "Gaudi's masterpiece" },
          { name: "Alhambra", description: "Moorish palace" },
          { name: "La Rambla", description: "Barcelona street" },
          { name: "Costa del Sol", description: "Beach resorts" },
          { name: "Flamenco Shows", description: "Traditional dance" }
        ]
      },
      { 
        name: "UK", 
        image: ukBigBen, 
        description: "Royal palaces and history",
        attractions: [
          { name: "Big Ben", description: "Iconic clock tower" },
          { name: "Buckingham Palace", description: "Royal residence" },
          { name: "Tower of London", description: "Historic castle" },
          { name: "Stonehenge", description: "Ancient monument" },
          { name: "Scottish Highlands", description: "Scenic landscapes" }
        ]
      },
      { 
        name: "Switzerland", 
        image: switzerlandAlps, 
        description: "Alpine beauty and chocolate",
        attractions: [
          { name: "Jungfraujoch", description: "Top of Europe viewpoint" },
          { name: "Lake Geneva", description: "Stunning alpine lake" },
          { name: "Matterhorn", description: "Iconic pyramid-shaped mountain" },
          { name: "Swiss Chocolate Tour", description: "Factory visits" },
          { name: "Rhine Falls", description: "Europe's largest waterfall" }
        ]
      },
      { 
        name: "Italy", 
        image: italyVenice, 
        description: "Art, history, and cuisine",
        attractions: [
          { name: "Colosseum", description: "Ancient amphitheater" },
          { name: "Venice Canals", description: "Gondola rides" },
          { name: "Leaning Tower", description: "Pisa landmark" },
          { name: "Vatican City", description: "Sistine Chapel" },
          { name: "Amalfi Coast", description: "Coastal beauty" }
        ]
      },
      { 
        name: "London", 
        image: londonTower, 
        description: "Historic capital with modern charm",
        attractions: [
          { name: "Tower Bridge", description: "Iconic bridge" },
          { name: "British Museum", description: "World artifacts" },
          { name: "London Eye", description: "Giant Ferris wheel" },
          { name: "Hyde Park", description: "Royal park" },
          { name: "West End", description: "Theater district" }
        ]
      }
    ],
    america: [
      { 
        name: "Canada", 
        image: canadaNiagara, 
        description: "Natural beauty and vibrant cities",
        attractions: [
          { name: "Niagara Falls", description: "Majestic waterfalls" },
          { name: "CN Tower", description: "Toronto landmark" },
          { name: "Banff National Park", description: "Rocky Mountains" },
          { name: "Old Montreal", description: "Historic quarter" },
          { name: "Vancouver", description: "Coastal city" }
        ]
      },
      { 
        name: "North America", 
        image: northamericaStatue, 
        description: "Diverse landscapes and cultures",
        attractions: [
          { name: "Statue of Liberty", description: "NYC icon" },
          { name: "Yellowstone", description: "First national park" },
          { name: "Las Vegas", description: "Entertainment capital" },
          { name: "Hollywood", description: "Movie capital" },
          { name: "Miami Beach", description: "Tropical paradise" }
        ]
      },
      { 
        name: "Central America", 
        image: centralamericaMayan, 
        description: "Ancient ruins and tropical beaches",
        attractions: [
          { name: "Mayan Ruins", description: "Ancient civilization" },
          { name: "Panama Canal", description: "Engineering marvel" },
          { name: "Costa Rica Rainforest", description: "Biodiversity hotspot" },
          { name: "Belize Barrier Reef", description: "Diving paradise" },
          { name: "Guatemala Lakes", description: "Volcanic lakes" }
        ]
      },
      { 
        name: "South America", 
        image: southamericaMachu, 
        description: "Machu Picchu and Amazon",
        attractions: [
          { name: "Machu Picchu", description: "Incan citadel" },
          { name: "Christ the Redeemer", description: "Rio landmark" },
          { name: "Amazon Rainforest", description: "World's lungs" },
          { name: "Iguazu Falls", description: "Massive waterfalls" },
          { name: "Patagonia", description: "Glaciers and peaks" }
        ]
      },
      { 
        name: "USA", 
        image: usaGrandCanyon, 
        description: "Diverse attractions coast to coast",
        attractions: [
          { name: "Grand Canyon", description: "Massive natural wonder" },
          { name: "Statue of Liberty", description: "Symbol of freedom" },
          { name: "Times Square", description: "Bright lights of New York" },
          { name: "Golden Gate Bridge", description: "San Francisco icon" },
          { name: "Disney World", description: "Magic Kingdom" }
        ]
      }
    ],
    honeymoon: [
      { 
        name: "Maldives", 
        image: maldivesResort, 
        description: "Overwater villas and crystal lagoons",
        attractions: [
          { name: "Overwater Bungalows", description: "Private luxury villas" },
          { name: "Couples Spa", description: "Beachside massage" },
          { name: "Underwater Dining", description: "Unique restaurant experience" },
          { name: "Snorkeling", description: "Coral reef exploration" },
          { name: "Sunset Cruises", description: "Romantic boat rides" }
        ]
      },
      { 
        name: "Bali", 
        image: baliRiceTerraces, 
        description: "Romantic beaches and cultural experiences",
        attractions: [
          { name: "Ubud Rice Terraces", description: "Scenic paddy fields" },
          { name: "Tanah Lot Temple", description: "Sunset temple on rocks" },
          { name: "Beach Clubs", description: "Luxury seaside lounging" },
          { name: "Couples Spa", description: "Traditional Balinese massage" },
          { name: "Uluwatu Cliff", description: "Dramatic ocean views" }
        ]
      },
      { 
        name: "Switzerland", 
        image: switzerlandAlps, 
        description: "Alpine romance and scenic beauty",
        attractions: [
          { name: "Interlaken", description: "Mountain views" },
          { name: "Swiss Alps", description: "Skiing and hiking" },
          { name: "Lucerne", description: "Lake city" },
          { name: "Glacier Express", description: "Scenic train" },
          { name: "Chocolate Tours", description: "Sweet experiences" }
        ]
      },
      { 
        name: "Paris", 
        image: parisEiffel, 
        description: "City of love with romantic ambiance",
        attractions: [
          { name: "Eiffel Tower", description: "Romantic landmark" },
          { name: "Seine River Cruise", description: "Boat ride" },
          { name: "Montmartre", description: "Artist quarter" },
          { name: "Romantic Cafes", description: "Parisian dining" },
          { name: "Palace of Versailles", description: "Royal gardens" }
        ]
      },
      { 
        name: "Italy", 
        image: italyVenice, 
        description: "Romance in Venice and Tuscany",
        attractions: [
          { name: "Venice Gondola", description: "Canal rides" },
          { name: "Tuscany Vineyards", description: "Wine tours" },
          { name: "Amalfi Coast", description: "Coastal beauty" },
          { name: "Rome Colosseum", description: "Ancient history" },
          { name: "Florence Art", description: "Renaissance masterpieces" }
        ]
      },
      { 
        name: "Thailand", 
        image: thailandPalace, 
        description: "Tropical paradise with luxury resorts",
        attractions: [
          { name: "Phuket Beaches", description: "Island romance" },
          { name: "Phi Phi Islands", description: "Beach hopping" },
          { name: "Bangkok Temples", description: "Cultural tours" },
          { name: "Couples Spa", description: "Thai massage" },
          { name: "Floating Markets", description: "Unique experience" }
        ]
      },
      { 
        name: "Dubai", 
        image: dubaiBurjKhalifa, 
        description: "Luxury and desert romance",
        attractions: [
          { name: "Burj Khalifa", description: "Sky-high views" },
          { name: "Desert Safari", description: "Romantic camping" },
          { name: "Luxury Hotels", description: "Five-star stays" },
          { name: "Private Beach", description: "Resort dining" },
          { name: "Dubai Mall", description: "Shopping experience" }
        ]
      },
      { 
        name: "Sri Lanka", 
        image: srilankaSigiriya, 
        description: "Island romance with tea estates",
        attractions: [
          { name: "Beach Resorts", description: "Tropical paradise" },
          { name: "Tea Plantations", description: "Hill country" },
          { name: "Wildlife Safari", description: "Yala National Park" },
          { name: "Cultural Sites", description: "Ancient temples" },
          { name: "Ayurveda Spa", description: "Wellness retreat" }
        ]
      },
      { 
        name: "Singapore", 
        image: singaporeMarina, 
        description: "Modern luxury and garden city",
        attractions: [
          { name: "Marina Bay", description: "Iconic views" },
          { name: "Sentosa Island", description: "Beach resort" },
          { name: "Fine Dining", description: "Michelin restaurants" },
          { name: "Gardens by the Bay", description: "Futuristic gardens" },
          { name: "Luxury Shopping", description: "Orchard Road" }
        ]
      },
      { 
        name: "Malaysia", 
        image: malaysiaTowers, 
        description: "Twin towers and tropical islands",
        attractions: [
          { name: "Langkawi", description: "Beach paradise" },
          { name: "Petronas Towers", description: "City skyline" },
          { name: "Cameron Highlands", description: "Tea estates" },
          { name: "Island Hopping", description: "Tropical beaches" },
          { name: "Luxury Resorts", description: "Romantic stays" }
        ]
      },
      { 
        name: "Spain", 
        image: spainSagrada, 
        description: "Mediterranean romance and culture",
        attractions: [
          { name: "Barcelona", description: "Gaudi architecture" },
          { name: "Costa del Sol", description: "Beach resorts" },
          { name: "Seville", description: "Flamenco shows" },
          { name: "Mallorca", description: "Island getaway" },
          { name: "Ibiza", description: "Romantic sunsets" }
        ]
      }
    ]
  };

  const handleDestinationClick = (destination: any) => {
    setSelectedDestination(destination);
    setDetailsOpen(true);
  };

  const handleEnquireFromDetails = () => {
    setDetailsOpen(false);
    setEnquiryContext({
      service: "International Tour",
      destination: selectedDestination?.name || ""
    });
    setEnquiryOpen(true);
  };

  const renderDestinationCards = (places: typeof destinationsData.asia) => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {places.map((destination, index) => (
        <Card 
          key={index} 
          className="overflow-hidden hover:shadow-xl transition-all duration-300 group cursor-pointer"
          onClick={() => handleDestinationClick(destination)}
        >
          <div className="relative h-56">
            <img 
              src={destination.image} 
              alt={destination.name}
              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-4">
              <h3 className="text-xl font-bold text-white mb-1">{destination.name}</h3>
              <p className="text-sm text-white/90">{destination.description}</p>
            </div>
            <div className="absolute top-4 left-4">
              <MapPin className="w-6 h-6 text-white drop-shadow-lg" />
            </div>
          </div>
        </Card>
      ))}
    </div>
  );

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[400px] flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${internationalToursImage})` }}
        />
        <div className="absolute inset-0 hero-overlay" />
        <div className="relative z-10 text-center text-white max-w-4xl mx-auto px-4">
          <h1 className="text-5xl md:text-6xl font-bold mb-4">International Tour Destinations</h1>
          <p className="text-xl md:text-2xl">Discover the World's Most Amazing Places</p>
        </div>
      </section>

      {/* Tours Section */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-foreground mb-4">Explore Destinations Worldwide</h2>
            <p className="text-lg text-muted-foreground">Click on any destination to learn more and plan your journey</p>
          </div>

          <Tabs defaultValue="asia" className="w-full">
            <TabsList className="grid w-full grid-cols-3 md:grid-cols-6 mb-8">
              <TabsTrigger value="asia">Asia</TabsTrigger>
              <TabsTrigger value="middleeast">Middle East</TabsTrigger>
              <TabsTrigger value="island">Islands</TabsTrigger>
              <TabsTrigger value="europe">Europe</TabsTrigger>
              <TabsTrigger value="america">America</TabsTrigger>
              <TabsTrigger value="honeymoon">Honeymoon</TabsTrigger>
            </TabsList>

            <TabsContent value="asia">
              {renderDestinationCards(destinationsData.asia)}
            </TabsContent>

            <TabsContent value="middleeast">
              {renderDestinationCards(destinationsData.middleEast)}
            </TabsContent>

            <TabsContent value="island">
              {renderDestinationCards(destinationsData.island)}
            </TabsContent>

            <TabsContent value="europe">
              {renderDestinationCards(destinationsData.europe)}
            </TabsContent>

            <TabsContent value="america">
              {renderDestinationCards(destinationsData.america)}
            </TabsContent>

            <TabsContent value="honeymoon">
              {renderDestinationCards(destinationsData.honeymoon)}
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 bg-primary text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready for an International Adventure?</h2>
          <p className="text-xl mb-8 opacity-90">
            Contact us to explore the world's most amazing destinations
          </p>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-8">
            <div className="flex items-center space-x-3">
              <Phone className="w-6 h-6" />
              <span className="text-lg">+91 99948-51869</span>
            </div>
            <div className="flex items-center space-x-3">
              <Mail className="w-6 h-6" />
              <span className="text-lg">trichy@vrholidays.co.in</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="btn-hero text-lg px-8 py-4"
              onClick={() => {
                setEnquiryContext({ service: "International Tour - Plan Your Trip", destination: "" });
                setEnquiryOpen(true);
              }}
            >
              Plan Your Trip
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="btn-outline-hero text-lg px-8 py-4"
              onClick={() => {
                setEnquiryContext({ service: "International Tour - Custom Itinerary", destination: "" });
                setEnquiryOpen(true);
              }}
            >
              Custom Itinerary
            </Button>
          </div>
        </div>
      </section>

      <DestinationDetailsDialog
        open={detailsOpen}
        onOpenChange={setDetailsOpen}
        destination={selectedDestination}
        onEnquireClick={handleEnquireFromDetails}
      />

      <EnquiryDialog
        open={enquiryOpen}
        onOpenChange={setEnquiryOpen}
        service={enquiryContext.service}
        destination={enquiryContext.destination}
      />
    </div>
  );
};

export default InternationalToursPage;