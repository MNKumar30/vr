import { useState } from "react";
import { Card } from "@/components/ui/card";
import { MapPin, Heart, Phone, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import DestinationDetailsDialog from "@/components/DestinationDetailsDialog";
import EnquiryDialog from "@/components/EnquiryDialog";

// Import destination images
import goaBeach from "@/assets/destinations/goa-beach.jpg";
import keralaBackwaters from "@/assets/destinations/kerala-backwaters.jpg";
import manaliMountains from "@/assets/destinations/manali-mountains.jpg";
import darjeelingTea from "@/assets/destinations/darjeeling-tea.jpg";
import maldivesResort from "@/assets/destinations/maldives-resort.jpg";
import baliRiceTerraces from "@/assets/destinations/bali-rice-terraces.jpg";
import parisEiffel from "@/assets/destinations/paris-eiffel.jpg";
import dubaiBurjKhalifa from "@/assets/destinations/dubai-burj-khalifa.jpg";
import singaporeMarina from "@/assets/destinations/singapore-marina.jpg";
import coorgCoffee from "@/assets/destinations/coorg-coffee.jpg";
import kodaikanalLake from "@/assets/destinations/kodaikanal-lake.jpg";
import kashmirDal from "@/assets/destinations/kashmir-dal.jpg";
import andamanBeach from "@/assets/destinations/andaman-beach.jpg";
import switzerlandAlps from "@/assets/destinations/switzerland-alps.jpg";
import italyVenice from "@/assets/destinations/italy-venice.jpg";
import thailandPalace from "@/assets/destinations/thailand-palace.jpg";
import srilankaSigiriya from "@/assets/destinations/srilanka-sigiriya.jpg";
import spainSagrada from "@/assets/destinations/spain-sagrada.jpg";
import shimlaMountains from "@/assets/destinations/shimla-mountains.jpg";
import ootyNilgiris from "@/assets/destinations/ooty-nilgiris.jpg";
import malaysiaTowers from "@/assets/destinations/malaysia-towers.jpg";
import indiaToursImage from "@/assets/india-tours.jpg";

const HoneymoonToursPage = () => {
  const [selectedDestination, setSelectedDestination] = useState<any>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [enquiryOpen, setEnquiryOpen] = useState(false);
  const [enquiryContext, setEnquiryContext] = useState({ service: "", destination: "" });

  const honeymoonDestinations = [
    // Domestic
    { 
      name: "Coorg", 
      image: coorgCoffee, 
      description: "Scotland of India with coffee plantations", 
      type: "Domestic",
      attractions: [
        { name: "Abbey Falls", description: "Romantic waterfall setting" },
        { name: "Coffee Estate Walks", description: "Aromatic plantation tours" },
        { name: "Raja's Seat", description: "Stunning sunset viewpoint" },
        { name: "Dubare Elephant Camp", description: "Elephant interactions" },
        { name: "Namdroling Monastery", description: "Golden Temple peace" }
      ]
    },
    { 
      name: "Darjeeling", 
      image: darjeelingTea, 
      description: "Romantic hill station with toy train", 
      type: "Domestic",
      attractions: [
        { name: "Toy Train Ride", description: "UNESCO heritage experience" },
        { name: "Tiger Hill Sunrise", description: "Kanchenjunga views" },
        { name: "Tea Garden Walks", description: "Romantic strolls" },
        { name: "Peace Pagoda", description: "Serene Buddhist shrine" },
        { name: "Mall Road", description: "Shopping and cafes" }
      ]
    },
    { 
      name: "Kashmir", 
      image: kashmirDal, 
      description: "Paradise for newlyweds", 
      type: "Domestic",
      attractions: [
        { name: "Dal Lake Shikara", description: "Romantic boat rides" },
        { name: "Mughal Gardens", description: "Beautiful Shalimar Bagh" },
        { name: "Gulmarg", description: "Ski resort and gondola" },
        { name: "Pahalgam", description: "Scenic valley" },
        { name: "Nishat Bagh", description: "Garden of joy" }
      ]
    },
    { 
      name: "Goa", 
      image: goaBeach, 
      description: "Beach romance with vibrant nightlife", 
      type: "Domestic",
      attractions: [
        { name: "Private Beach Dinners", description: "Candlelight by the sea" },
        { name: "Dudhsagar Trek", description: "Waterfall adventure" },
        { name: "Sunset Cruises", description: "Romantic boat rides" },
        { name: "Fort Aguada", description: "Historic fort" },
        { name: "Beach Shacks", description: "Romantic dining" }
      ]
    },
    { 
      name: "Andaman", 
      image: andamanBeach, 
      description: "Pristine islands with crystal waters", 
      type: "Domestic",
      attractions: [
        { name: "Radhanagar Beach", description: "Asia's best beach" },
        { name: "Scuba Diving", description: "Explore coral reefs" },
        { name: "Havelock Island", description: "Beach paradise" },
        { name: "Neil Island", description: "Secluded beaches" },
        { name: "Cellular Jail", description: "Historic landmark" }
      ]
    },
    { 
      name: "Kerala", 
      image: keralaBackwaters, 
      description: "Romantic backwater houseboats", 
      type: "Domestic",
      attractions: [
        { name: "Houseboat Cruise", description: "Private backwater experience" },
        { name: "Ayurvedic Spa", description: "Couples massage" },
        { name: "Alleppey Backwaters", description: "Serene waterways" },
        { name: "Munnar", description: "Tea garden hillstation" },
        { name: "Vembanad Lake", description: "Scenic lake views" }
      ]
    },
    { 
      name: "Maldives", 
      image: maldivesResort, 
      description: "Overwater villas and crystal lagoons", 
      type: "International",
      attractions: [
        { name: "Overwater Bungalows", description: "Private luxury villas" },
        { name: "Couples Spa", description: "Beachside massage" },
        { name: "Underwater Dining", description: "Unique restaurant experience" },
        { name: "Snorkeling", description: "Coral reef exploration" },
        { name: "Sunset Cruises", description: "Romantic boat rides" }
      ]
    },
    { 
      name: "Bali", 
      image: baliRiceTerraces, 
      description: "Romantic beaches and cultural experiences", 
      type: "International",
      attractions: [
        { name: "Ubud Rice Terraces", description: "Scenic paddy fields" },
        { name: "Tanah Lot Temple", description: "Sunset temple on rocks" },
        { name: "Beach Clubs", description: "Luxury seaside lounging" },
        { name: "Couples Spa", description: "Traditional Balinese massage" },
        { name: "Uluwatu Cliff", description: "Dramatic ocean views" }
      ]
    },
    { 
      name: "Switzerland", 
      image: switzerlandAlps, 
      description: "Alpine romance and scenic beauty", 
      type: "International",
      attractions: [
        { name: "Interlaken", description: "Mountain paradise" },
        { name: "Swiss Alps", description: "Skiing and hiking" },
        { name: "Lucerne", description: "Romantic lake city" },
        { name: "Glacier Express", description: "Scenic train journey" },
        { name: "Chocolate Tours", description: "Sweet experiences" }
      ]
    },
    { 
      name: "Paris", 
      image: parisEiffel, 
      description: "City of love with romantic ambiance", 
      type: "International",
      attractions: [
        { name: "Eiffel Tower", description: "Iconic romantic landmark" },
        { name: "Seine River Cruise", description: "Romantic boat ride" },
        { name: "Montmartre", description: "Artist quarter" },
        { name: "Romantic Cafes", description: "Parisian dining" },
        { name: "Palace of Versailles", description: "Royal gardens" }
      ]
    },
    { 
      name: "Italy", 
      image: italyVenice, 
      description: "Romance in Venice and Tuscany", 
      type: "International",
      attractions: [
        { name: "Venice Gondola", description: "Romantic canal rides" },
        { name: "Tuscany Vineyards", description: "Wine tours" },
        { name: "Amalfi Coast", description: "Coastal beauty" },
        { name: "Rome Colosseum", description: "Ancient romance" },
        { name: "Florence Art", description: "Renaissance beauty" }
      ]
    },
    { 
      name: "Thailand", 
      image: thailandPalace, 
      description: "Tropical paradise with luxury resorts", 
      type: "International",
      attractions: [
        { name: "Phuket Beaches", description: "Island romance" },
        { name: "Phi Phi Islands", description: "Beach paradise" },
        { name: "Bangkok Temples", description: "Cultural experience" },
        { name: "Couples Spa", description: "Traditional Thai massage" },
        { name: "Floating Markets", description: "Unique experience" }
      ]
    },
    { 
      name: "Dubai", 
      image: dubaiBurjKhalifa, 
      description: "Luxury and desert romance", 
      type: "International",
      attractions: [
        { name: "Burj Khalifa", description: "Sky-high romantic views" },
        { name: "Desert Safari", description: "Romantic camping" },
        { name: "Luxury Hotels", description: "Five-star stays" },
        { name: "Private Beach", description: "Resort dining" },
        { name: "Dubai Mall", description: "Shopping luxury" }
      ]
    },
    { 
      name: "Sri Lanka", 
      image: srilankaSigiriya, 
      description: "Island romance with tea estates", 
      type: "International",
      attractions: [
        { name: "Beach Resorts", description: "Tropical paradise" },
        { name: "Tea Plantations", description: "Hill country romance" },
        { name: "Wildlife Safari", description: "Yala adventure" },
        { name: "Cultural Sites", description: "Ancient temples" },
        { name: "Ayurveda Spa", description: "Wellness retreat" }
      ]
    },
    { 
      name: "Singapore", 
      image: singaporeMarina, 
      description: "Modern luxury and garden city", 
      type: "International",
      attractions: [
        { name: "Marina Bay", description: "Iconic city views" },
        { name: "Sentosa Island", description: "Beach resort luxury" },
        { name: "Fine Dining", description: "Michelin restaurants" },
        { name: "Gardens by the Bay", description: "Futuristic romance" },
        { name: "Luxury Shopping", description: "Orchard Road" }
      ]
    },
    { 
      name: "Malaysia", 
      image: malaysiaTowers, 
      description: "Twin towers and tropical islands", 
      type: "International",
      attractions: [
        { name: "Langkawi", description: "Beach paradise" },
        { name: "Petronas Towers", description: "Iconic skyline" },
        { name: "Cameron Highlands", description: "Tea estate romance" },
        { name: "Island Hopping", description: "Tropical adventures" },
        { name: "Luxury Resorts", description: "Romantic getaways" }
      ]
    },
    { 
      name: "Spain", 
      image: spainSagrada, 
      description: "Mediterranean romance and culture", 
      type: "International",
      attractions: [
        { name: "Barcelona", description: "Gaudi's masterpieces" },
        { name: "Costa del Sol", description: "Beach resorts" },
        { name: "Seville", description: "Flamenco romance" },
        { name: "Mallorca", description: "Island paradise" },
        { name: "Ibiza", description: "Romantic sunsets" }
      ]
    },
    { 
      name: "Shimla", 
      image: shimlaMountains, 
      description: "Queen of Hill Stations", 
      type: "Domestic",
      attractions: [
        { name: "Mall Road", description: "Romantic strolls" },
        { name: "Jakhu Temple", description: "Panoramic mountain views" },
        { name: "Ice Skating", description: "Winter romance" },
        { name: "Toy Train", description: "UNESCO heritage ride" },
        { name: "Kufri", description: "Adventure together" }
      ]
    },
    { 
      name: "Ooty", 
      image: ootyNilgiris, 
      description: "Queen of Nilgiris", 
      type: "Domestic",
      attractions: [
        { name: "Botanical Gardens", description: "Romantic walks" },
        { name: "Ooty Lake", description: "Boating together" },
        { name: "Nilgiri Mountain Railway", description: "Scenic toy train" },
        { name: "Doddabetta Peak", description: "Mountain views" },
        { name: "Tea Gardens", description: "Peaceful estates" }
      ]
    }
  ];

  const handleDestinationClick = (destination: any) => {
    setSelectedDestination(destination);
    setDetailsOpen(true);
  };

  const handleEnquireFromDetails = () => {
    setDetailsOpen(false);
    setEnquiryContext({
      service: "Honeymoon Tour",
      destination: selectedDestination?.name || ""
    });
    setEnquiryOpen(true);
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[400px] flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${indiaToursImage})` }}
        />
        <div className="absolute inset-0 hero-overlay" />
        <div className="relative z-10 text-center text-white max-w-4xl mx-auto px-4">
          <Heart className="w-16 h-16 mx-auto mb-4 text-red-400" />
          <h1 className="text-5xl md:text-6xl font-bold mb-4">Honeymoon Destinations</h1>
          <p className="text-xl md:text-2xl">Create Unforgettable Memories Together</p>
        </div>
      </section>

      {/* Destinations Section */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-foreground mb-4">Romantic Destinations for Newlyweds</h2>
            <p className="text-lg text-muted-foreground">
              Click on any destination to plan your perfect romantic getaway
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {honeymoonDestinations.map((destination, index) => (
              <Card 
                key={index} 
                className="overflow-hidden hover:shadow-xl transition-all duration-300 group cursor-pointer"
                onClick={() => handleDestinationClick(destination)}
              >
                <div className="relative h-56">
                  <img 
                    src={destination.image} 
                    alt={destination.name}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-4">
                    <h3 className="text-xl font-bold text-white mb-1">{destination.name}</h3>
                    <p className="text-sm text-white/90">{destination.description}</p>
                  </div>
                  <div className="absolute top-4 left-4">
                    <Heart className="w-6 h-6 text-red-400 fill-current drop-shadow-lg" />
                  </div>
                  <div className="absolute top-4 right-4 bg-red-500 text-white px-3 py-1 rounded-full text-xs font-medium">
                    {destination.type}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Special Features */}
      <section className="py-16 bg-secondary/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-foreground mb-4">Why Choose Us for Your Honeymoon</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-8 h-8 text-red-500" />
              </div>
              <h3 className="text-xl font-bold text-foreground mb-2">Romantic Experiences</h3>
              <p className="text-muted-foreground">
                Candlelight dinners, private beach access, and couple activities designed for romance
              </p>
            </div>
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-accent/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="w-8 h-8 text-accent" />
              </div>
              <h3 className="text-xl font-bold text-foreground mb-2">Luxury Accommodations</h3>
              <p className="text-muted-foreground">
                Stay in premium resorts and hotels with special honeymoon suites and amenities
              </p>
            </div>
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-8 h-8 text-primary fill-current" />
              </div>
              <h3 className="text-xl font-bold text-foreground mb-2">Customizable Packages</h3>
              <p className="text-muted-foreground">
                Tailor your honeymoon to your preferences with flexible itineraries and activities
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 bg-primary text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Plan Your Dream Honeymoon?</h2>
          <p className="text-xl mb-8 opacity-90">
            Let us help you create magical memories that will last a lifetime
          </p>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-8">
            <div className="flex items-center space-x-3">
              <Phone className="w-6 h-6" />
              <span className="text-lg">+91 99948-51869</span>
            </div>
            <div className="flex items-center space-x-3">
              <Mail className="w-6 h-6" />
              <span className="text-lg">trichy@vrholidays.co.in</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="btn-hero text-lg px-8 py-4"
              onClick={() => {
                setEnquiryContext({ service: "Honeymoon Tour - Plan Your Honeymoon", destination: "" });
                setEnquiryOpen(true);
              }}
            >
              Plan Your Honeymoon
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="btn-outline-hero text-lg px-8 py-4"
              onClick={() => {
                setEnquiryContext({ service: "Honeymoon Tour - Customize Package", destination: "" });
                setEnquiryOpen(true);
              }}
            >
              Customize Your Package
            </Button>
          </div>
        </div>
      </section>

      <DestinationDetailsDialog
        open={detailsOpen}
        onOpenChange={setDetailsOpen}
        destination={selectedDestination}
        onEnquireClick={handleEnquireFromDetails}
      />

      <EnquiryDialog
        open={enquiryOpen}
        onOpenChange={setEnquiryOpen}
        service={enquiryContext.service}
        destination={enquiryContext.destination}
      />
    </div>
  );
};

export default HoneymoonToursPage;