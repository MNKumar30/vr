import ServiceTemplate from "./ServiceTemplate";
import visaAssistanceImage from "@/assets/visa-assistance.jpg";

const PassportAppointmentPage = () => {
  const services = [
    {
      title: "New Passport Application",
      description: "Complete assistance for new passport applications with document verification.",
      features: ["Form Filling", "Document Verification", "Appointment Booking", "Status Tracking"]
    },
    {
      title: "Passport Renewal",
      description: "Hassle-free passport renewal services with fast processing options.",
      features: ["Quick Renewal", "Document Support", "Appointment Scheduling", "Home Pickup"]
    },
    {
      title: "Tatkal Passport",
      description: "Emergency passport services for urgent travel requirements.",
      features: ["Same Day Appointment", "Urgent Processing", "Document Assistance", "Priority Service"]
    }
  ];

  return (
    <ServiceTemplate
      title="Passport Appointment"
      description="Hassle-Free Passport Services & Appointment Booking"
      heroImage={visaAssistanceImage}
      services={services}
      ctaTitle="Need Passport Services?"
      ctaDescription="Get expert assistance for all your passport related requirements from application to renewal"
      primaryButtonText="Book Appointment"
      secondaryButtonText="Check Status"
    />
  );
};

export default PassportAppointmentPage;