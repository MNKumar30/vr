import ServiceTemplate from "./ServiceTemplate";
import moneyTransferImage from "@/assets/money-transfer.jpg";

const MoneyTransferPage = () => {
  const services = [
    {
      title: "International Money Transfer",
      description: "Send money abroad quickly and securely to over 200 countries worldwide.",
      features: ["200+ Countries", "Competitive Rates", "Fast Processing", "Secure Transfers"],
      price: "Low Transfer Fees"
    },
    {
      title: "Online Money Transfer",
      description: "Transfer money online from the comfort of your home with our digital platform.",
      features: ["24/7 Online Service", "Real-time Tracking", "Multiple Payment Options", "Mobile App"],
      price: "Starting ₹100"
    },
    {
      title: "Cash Pickup Service",
      description: "Recipient can collect cash from authorized locations worldwide.",
      features: ["Global Network", "Quick Pickup", "No Bank Account Needed", "SMS Notifications"],
      price: "Instant Transfer"
    }
  ];

  return (
    <ServiceTemplate
      title="Send Money Abroad"
      description="Fast, Secure & Affordable International Money Transfers"
      heroImage={moneyTransferImage}
      services={services}
      ctaTitle="Send Money Today"
      ctaDescription="Transfer money to your loved ones abroad with our fast and secure money transfer services"
      primaryButtonText="Send Money"
      secondaryButtonText="Calculate Fees"
    />
  );
};

export default MoneyTransferPage;