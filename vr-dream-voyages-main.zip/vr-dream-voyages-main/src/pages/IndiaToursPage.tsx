import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MapPin, Phone, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import DestinationDetailsDialog from "@/components/DestinationDetailsDialog";
import EnquiryDialog from "@/components/EnquiryDialog";

// Import destination images
import agraTajMahal from "@/assets/destinations/agra-taj-mahal.jpg";
import manaliMountains from "@/assets/destinations/manali-mountains.jpg";
import jaipurHawaMahal from "@/assets/destinations/jaipur-hawa-mahal.jpg";
import keralaBackwaters from "@/assets/destinations/kerala-backwaters.jpg";
import goaBeach from "@/assets/destinations/goa-beach.jpg";
import ladakhPangong from "@/assets/destinations/ladakh-pangong.jpg";
import darjeelingTea from "@/assets/destinations/darjeeling-tea.jpg";
import tamilnaduTemples from "@/assets/destinations/tamilnadu-temples.jpg";
import karnatakaMysore from "@/assets/destinations/karnataka-mysore.jpg";
import mumbaiGateway from "@/assets/destinations/mumbai-gateway.jpg";
import rajasthanForts from "@/assets/destinations/rajasthan-forts.jpg";
import gujaratRann from "@/assets/destinations/gujarat-rann.jpg";
import westbengalBridge from "@/assets/destinations/westbengal-bridge.jpg";
import kolkataVictoria from "@/assets/destinations/kolkata-victoria.jpg";
import arunachalTawang from "@/assets/destinations/arunachal-tawang.jpg";
import meghalayaBridges from "@/assets/destinations/meghalaya-bridges.jpg";
import sikkimLake from "@/assets/destinations/sikkim-lake.jpg";
import assamKaziranga from "@/assets/destinations/assam-kaziranga.jpg";
import nagalandFestival from "@/assets/destinations/nagaland-festival.jpg";
import gangtokMarg from "@/assets/destinations/gangtok-marg.jpg";
import pellingKanchenjunga from "@/assets/destinations/pelling-kanchenjunga.jpg";
import delhiIndiaGate from "@/assets/destinations/delhi-indiagate.jpg";
import udaipurPalace from "@/assets/destinations/udaipur-palace.jpg";
import kashmirDal from "@/assets/destinations/kashmir-dal.jpg";
import coorgCoffee from "@/assets/destinations/coorg-coffee.jpg";
import kodaikanalLake from "@/assets/destinations/kodaikanal-lake.jpg";
import andamanBeach from "@/assets/destinations/andaman-beach.jpg";
import shimlaMountains from "@/assets/destinations/shimla-mountains.jpg";
import ootyNilgiris from "@/assets/destinations/ooty-nilgiris.jpg";
import indiaToursImage from "@/assets/india-tours.jpg";

const IndiaToursPage = () => {
  const [selectedDestination, setSelectedDestination] = useState<any>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [enquiryOpen, setEnquiryOpen] = useState(false);
  const [enquiryContext, setEnquiryContext] = useState({ service: "", destination: "" });

  const destinationsData = {
    northIndia: [
      { 
        name: "Delhi", 
        image: delhiIndiaGate, 
        description: "The vibrant capital with rich Mughal heritage",
        attractions: [
          { name: "India Gate", description: "War memorial and iconic landmark" },
          { name: "Red Fort", description: "Historic Mughal fortress" },
          { name: "Qutub Minar", description: "Tallest brick minaret in the world" },
          { name: "Lotus Temple", description: "Stunning Bahá'í House of Worship" },
          { name: "Humayun's Tomb", description: "UNESCO World Heritage Site" }
        ]
      },
      { 
        name: "Agra", 
        image: agraTajMahal, 
        description: "Home to the magnificent Taj Mahal",
        attractions: [
          { name: "Taj Mahal", description: "Symbol of eternal love, UNESCO site" },
          { name: "Agra Fort", description: "Red sandstone Mughal fortress" },
          { name: "Fatehpur Sikri", description: "Abandoned Mughal city" },
          { name: "Mehtab Bagh", description: "Garden with Taj Mahal sunset views" },
          { name: "Itmad-ud-Daulah", description: "Baby Taj marble mausoleum" }
        ]
      },
      { 
        name: "Manali", 
        image: manaliMountains, 
        description: "Snow-capped mountains and adventure sports",
        attractions: [
          { name: "Rohtang Pass", description: "High mountain pass with snow" },
          { name: "Solang Valley", description: "Adventure sports hub" },
          { name: "Hadimba Temple", description: "Ancient cave temple" },
          { name: "Old Manali", description: "Hippie village with cafes" },
          { name: "Manu Temple", description: "Sacred Hindu temple" }
        ]
      },
      { 
        name: "Jaipur", 
        image: jaipurHawaMahal, 
        description: "The Pink City of majestic forts and palaces",
        attractions: [
          { name: "Hawa Mahal", description: "Palace of Winds with 953 windows" },
          { name: "Amber Fort", description: "Majestic hilltop fortress" },
          { name: "City Palace", description: "Royal residence and museum" },
          { name: "Jantar Mantar", description: "Astronomical observatory" },
          { name: "Jal Mahal", description: "Water palace in Man Sagar Lake" }
        ]
      },
      { 
        name: "Shimla", 
        image: shimlaMountains, 
        description: "The Queen of Hill Stations with colonial charm",
        attractions: [
          { name: "Mall Road", description: "Famous shopping street" },
          { name: "Jakhu Temple", description: "Hilltop Hanuman temple" },
          { name: "Christ Church", description: "Gothic revival church" },
          { name: "Kufri", description: "Ski resort and adventure sports" },
          { name: "Ridge", description: "Open space with mountain views" }
        ]
      },
      { 
        name: "Udaipur", 
        image: udaipurPalace, 
        description: "City of Lakes with romantic palaces",
        attractions: [
          { name: "City Palace", description: "Majestic lakeside palace" },
          { name: "Lake Pichola", description: "Beautiful boat rides" },
          { name: "Jag Mandir", description: "Island palace" },
          { name: "Saheliyon Ki Bari", description: "Garden of maidens" },
          { name: "Monsoon Palace", description: "Hilltop sunset views" }
        ]
      },
      { 
        name: "Jammu & Kashmir", 
        image: kashmirDal, 
        description: "Paradise on Earth with stunning valleys",
        attractions: [
          { name: "Dal Lake", description: "Iconic shikara rides" },
          { name: "Gulmarg", description: "World-class skiing" },
          { name: "Pahalgam", description: "Scenic valley town" },
          { name: "Mughal Gardens", description: "Beautiful Shalimar Bagh" },
          { name: "Sonamarg", description: "Meadow of gold" }
        ]
      },
      { 
        name: "Leh-Ladakh", 
        image: ladakhPangong, 
        description: "High altitude desert with stunning landscapes",
        attractions: [
          { name: "Pangong Lake", description: "Blue high-altitude lake" },
          { name: "Nubra Valley", description: "Cold desert with camels" },
          { name: "Magnetic Hill", description: "Gravity-defying phenomenon" },
          { name: "Khardung La", description: "World's highest motorable pass" },
          { name: "Monasteries", description: "Ancient Buddhist temples" }
        ]
      }
    ],
    southIndia: [
      { 
        name: "Tamil Nadu", 
        image: tamilnaduTemples, 
        description: "Ancient temples and rich cultural heritage",
        attractions: [
          { name: "Meenakshi Temple", description: "Stunning Dravidian architecture" },
          { name: "Mahabalipuram", description: "UNESCO rock-cut monuments" },
          { name: "Rameswaram", description: "Sacred pilgrimage island" },
          { name: "Ooty", description: "Queen of hill stations" },
          { name: "Kanyakumari", description: "Southernmost tip of India" }
        ]
      },
      { 
        name: "Kerala", 
        image: keralaBackwaters, 
        description: "God's Own Country with serene backwaters",
        attractions: [
          { name: "Alleppey Backwaters", description: "Houseboat cruises" },
          { name: "Munnar Tea Gardens", description: "Scenic hill station" },
          { name: "Periyar Wildlife", description: "Elephant sanctuary" },
          { name: "Kovalam Beach", description: "Popular beach destination" },
          { name: "Kathakali Shows", description: "Traditional dance performances" }
        ]
      },
      { 
        name: "Karnataka", 
        image: karnatakaMysore, 
        description: "Garden city and historic monuments",
        attractions: [
          { name: "Mysore Palace", description: "Indo-Saracenic royal palace" },
          { name: "Hampi Ruins", description: "UNESCO Vijayanagara Empire ruins" },
          { name: "Coorg Coffee Estates", description: "Scotland of India" },
          { name: "Bangalore Gardens", description: "Lalbagh and Cubbon Park" },
          { name: "Gokarna Beaches", description: "Peaceful coastal town" }
        ]
      }
    ],
    westIndia: [
      { 
        name: "Mumbai", 
        image: mumbaiGateway, 
        description: "The city of dreams and Bollywood",
        attractions: [
          { name: "Gateway of India", description: "Iconic monument" },
          { name: "Marine Drive", description: "Queen's Necklace promenade" },
          { name: "Elephanta Caves", description: "UNESCO World Heritage Site" },
          { name: "Film City", description: "Bollywood studios tour" },
          { name: "Chhatrapati Terminus", description: "Victorian Gothic architecture" }
        ]
      },
      { 
        name: "Goa", 
        image: goaBeach, 
        description: "Beach paradise with Portuguese heritage",
        attractions: [
          { name: "Baga Beach", description: "Water sports and nightlife" },
          { name: "Basilica of Bom Jesus", description: "UNESCO World Heritage church" },
          { name: "Fort Aguada", description: "Portuguese coastal fort" },
          { name: "Dudhsagar Falls", description: "Majestic waterfalls" },
          { name: "Anjuna Flea Market", description: "Shopping and culture" }
        ]
      },
      { 
        name: "Rajasthan", 
        image: rajasthanForts, 
        description: "Land of maharajas and desert forts",
        attractions: [
          { name: "Jaisalmer Fort", description: "Living golden fort" },
          { name: "Mehrangarh Fort", description: "Majestic Jodhpur fort" },
          { name: "Pushkar Lake", description: "Sacred Hindu pilgrimage" },
          { name: "Thar Desert Safari", description: "Camel rides and dunes" },
          { name: "Ranthambore", description: "Tiger sanctuary" }
        ]
      },
      { 
        name: "Gujarat", 
        image: gujaratRann, 
        description: "Vibrant culture and diverse landscapes",
        attractions: [
          { name: "Rann of Kutch", description: "White salt desert" },
          { name: "Gir Forest", description: "Asiatic lions sanctuary" },
          { name: "Somnath Temple", description: "Ancient Shiva temple" },
          { name: "Sabarmati Ashram", description: "Gandhi's residence" },
          { name: "Dwarka", description: "Sacred Krishna city" }
        ]
      }
    ],
    eastIndia: [
      { 
        name: "West Bengal", 
        image: westbengalBridge, 
        description: "Cultural capital with literary heritage",
        attractions: [
          { name: "Howrah Bridge", description: "Iconic cantilever bridge" },
          { name: "Victoria Memorial", description: "White marble building" },
          { name: "Sundarbans", description: "Mangrove forest and tigers" },
          { name: "Marble Palace", description: "19th century mansion" },
          { name: "Kalighat Temple", description: "Sacred Kali temple" }
        ]
      },
      { 
        name: "Darjeeling", 
        image: darjeelingTea, 
        description: "Queen of hills with famous tea gardens",
        attractions: [
          { name: "Tiger Hill", description: "Sunrise over Kanchenjunga" },
          { name: "Toy Train", description: "UNESCO heritage railway" },
          { name: "Tea Gardens", description: "World-famous tea estates" },
          { name: "Peace Pagoda", description: "Buddhist stupa" },
          { name: "Himalayan Zoo", description: "Red panda sanctuary" }
        ]
      },
      { 
        name: "Kolkata", 
        image: kolkataVictoria, 
        description: "City of joy with colonial architecture",
        attractions: [
          { name: "Victoria Memorial", description: "Grand marble building" },
          { name: "Indian Museum", description: "Oldest museum in India" },
          { name: "Park Street", description: "Food and shopping hub" },
          { name: "Durga Puja Pandals", description: "Festival celebrations" },
          { name: "Belur Math", description: "Ramakrishna temple" }
        ]
      }
    ],
    northeastIndia: [
      { 
        name: "Arunachal Pradesh", 
        image: arunachalTawang, 
        description: "Land of dawn-lit mountains",
        attractions: [
          { name: "Tawang Monastery", description: "Largest monastery in India" },
          { name: "Sela Pass", description: "High altitude mountain pass" },
          { name: "Bumla Pass", description: "Indo-China border" },
          { name: "Madhuri Lake", description: "Scenic high-altitude lake" },
          { name: "War Memorial", description: "1962 war tribute" }
        ]
      },
      { 
        name: "Meghalaya", 
        image: meghalayaBridges, 
        description: "Abode of clouds with living root bridges",
        attractions: [
          { name: "Double Decker Root Bridge", description: "Natural living bridges" },
          { name: "Cherrapunji", description: "Wettest place on earth" },
          { name: "Umiam Lake", description: "Beautiful reservoir" },
          { name: "Mawlynnong Village", description: "Cleanest village in Asia" },
          { name: "Nohkalikai Falls", description: "Tallest plunge waterfall" }
        ]
      },
      { 
        name: "Sikkim", 
        image: sikkimLake, 
        description: "Himalayan beauty with monasteries",
        attractions: [
          { name: "Tsomgo Lake", description: "Glacial high-altitude lake" },
          { name: "Nathula Pass", description: "Indo-China border crossing" },
          { name: "Rumtek Monastery", description: "Largest monastery in Sikkim" },
          { name: "Yumthang Valley", description: "Valley of flowers" },
          { name: "Pelling Skywalk", description: "Glass bridge with views" }
        ]
      },
      { 
        name: "Assam", 
        image: assamKaziranga, 
        description: "Land of tea gardens and wildlife",
        attractions: [
          { name: "Kaziranga National Park", description: "One-horned rhino sanctuary" },
          { name: "Majuli Island", description: "World's largest river island" },
          { name: "Kamakhya Temple", description: "Ancient Shakti Peetha" },
          { name: "Tea Gardens", description: "Sprawling Assam tea estates" },
          { name: "Brahmaputra River Cruise", description: "Scenic river journey" }
        ]
      },
      { 
        name: "Nagaland", 
        image: nagalandFestival, 
        description: "Tribal culture and scenic hills",
        attractions: [
          { name: "Hornbill Festival", description: "Festival of festivals" },
          { name: "Kohima War Cemetery", description: "WWII memorial" },
          { name: "Dzukou Valley", description: "Valley of flowers" },
          { name: "Naga Heritage Village", description: "Tribal culture showcase" },
          { name: "Japfu Peak", description: "Trekking destination" }
        ]
      },
      { 
        name: "Gangtok", 
        image: gangtokMarg, 
        description: "Capital city with stunning mountain views",
        attractions: [
          { name: "MG Marg", description: "Pedestrian shopping street" },
          { name: "Enchey Monastery", description: "200-year-old monastery" },
          { name: "Hanuman Tok", description: "Temple with panoramic views" },
          { name: "Banjhakri Falls", description: "Waterfall and park" },
          { name: "Ropeway Cable Car", description: "Aerial city views" }
        ]
      },
      { 
        name: "Pelling", 
        image: pellingKanchenjunga, 
        description: "Peaceful town with Kanchenjunga views",
        attractions: [
          { name: "Pemayangtse Monastery", description: "Ancient Buddhist monastery" },
          { name: "Khecheopalri Lake", description: "Sacred wish-fulfilling lake" },
          { name: "Kanchenjunga Falls", description: "Spectacular waterfalls" },
          { name: "Skywalk", description: "Glass bridge with mountain views" },
          { name: "Rabdentse Ruins", description: "Ancient Sikkim capital ruins" }
        ]
      }
    ],
    honeymoon: [
      { 
        name: "Coorg", 
        image: coorgCoffee, 
        description: "Scotland of India with coffee plantations",
        attractions: [
          { name: "Abbey Falls", description: "Romantic waterfall" },
          { name: "Coffee Plantations", description: "Aromatic estate walks" },
          { name: "Raja's Seat", description: "Sunset viewpoint" },
          { name: "Dubare Elephant Camp", description: "Elephant interactions" },
          { name: "Namdroling Monastery", description: "Golden Temple" }
        ]
      },
      { 
        name: "Darjeeling", 
        image: darjeelingTea, 
        description: "Romantic hill station with toy train",
        attractions: [
          { name: "Toy Train Ride", description: "UNESCO heritage experience" },
          { name: "Tiger Hill Sunrise", description: "Kanchenjunga sunrise views" },
          { name: "Tea Garden Walks", description: "Romantic strolls" },
          { name: "Peace Pagoda", description: "Serene Buddhist shrine" },
          { name: "Mall Road", description: "Shopping and cafes" }
        ]
      },
      { 
        name: "Kashmir", 
        image: kashmirDal, 
        description: "Paradise for newlyweds",
        attractions: [
          { name: "Dal Lake Shikara", description: "Romantic boat rides" },
          { name: "Mughal Gardens", description: "Beautiful Shalimar Bagh" },
          { name: "Gulmarg", description: "Ski resort and gondola" },
          { name: "Pahalgam", description: "Scenic valley" },
          { name: "Nishat Bagh", description: "Garden of joy" }
        ]
      },
      { 
        name: "Goa", 
        image: goaBeach, 
        description: "Beach romance with vibrant nightlife",
        attractions: [
          { name: "Private Beach Dinners", description: "Candlelight by the sea" },
          { name: "Dudhsagar Trek", description: "Waterfall adventure" },
          { name: "Sunset Cruises", description: "Romantic boat rides" },
          { name: "Fort Aguada", description: "Historic Portuguese fort" },
          { name: "Beach Shacks", description: "Romantic dining spots" }
        ]
      },
      { 
        name: "Kerala", 
        image: keralaBackwaters, 
        description: "Romantic backwater houseboats",
        attractions: [
          { name: "Houseboat Cruise", description: "Private backwater experience" },
          { name: "Ayurvedic Spa", description: "Couples massage" },
          { name: "Alleppey Backwaters", description: "Serene waterways" },
          { name: "Munnar Tea Gardens", description: "Romantic hillstation" },
          { name: "Vembanad Lake", description: "Scenic lake views" }
        ]
      },
      { 
        name: "Kodaikanal", 
        image: kodaikanalLake, 
        description: "Princess of Hill Stations",
        attractions: [
          { name: "Kodai Lake", description: "Star-shaped lake" },
          { name: "Coaker's Walk", description: "Scenic walkway" },
          { name: "Bryant Park", description: "Botanical garden" },
          { name: "Pillar Rocks", description: "Natural rock formations" },
          { name: "Silver Cascade Falls", description: "Beautiful waterfalls" }
        ]
      },
      { 
        name: "Andaman", 
        image: andamanBeach, 
        description: "Pristine islands with crystal waters",
        attractions: [
          { name: "Radhanagar Beach", description: "Asia's best beach" },
          { name: "Scuba Diving", description: "Explore coral reefs together" },
          { name: "Havelock Island", description: "Romantic beach paradise" },
          { name: "Neil Island", description: "Secluded beaches" },
          { name: "Cellular Jail", description: "Historic lighthouse" }
        ]
      },
      { 
        name: "Shimla", 
        image: shimlaMountains, 
        description: "Queen of Hill Stations",
        attractions: [
          { name: "Mall Road", description: "Shopping and cafes" },
          { name: "Jakhu Temple", description: "Panoramic views" },
          { name: "Ice Skating", description: "Winter sports" },
          { name: "Toy Train", description: "UNESCO heritage railway" },
          { name: "Kufri", description: "Adventure activities" }
        ]
      },
      { 
        name: "Manali", 
        image: manaliMountains, 
        description: "Adventure capital of Himachal",
        attractions: [
          { name: "Rohtang Pass", description: "Snow activities" },
          { name: "Solang Valley", description: "Skiing and paragliding" },
          { name: "Hadimba Temple", description: "Ancient wooden temple" },
          { name: "Old Manali", description: "Hippie cafes" },
          { name: "Hot Springs", description: "Natural thermal baths" }
        ]
      },
      { 
        name: "Ooty", 
        image: ootyNilgiris, 
        description: "Queen of Nilgiris",
        attractions: [
          { name: "Botanical Gardens", description: "Lush gardens" },
          { name: "Ooty Lake", description: "Boating and picnics" },
          { name: "Nilgiri Mountain Railway", description: "Toy train ride" },
          { name: "Doddabetta Peak", description: "Highest peak in Nilgiris" },
          { name: "Tea Gardens", description: "Scenic tea estates" }
        ]
      }
    ]
  };

  const handleDestinationClick = (destination: any) => {
    setSelectedDestination(destination);
    setDetailsOpen(true);
  };

  const handleEnquireFromDetails = () => {
    setDetailsOpen(false);
    setEnquiryContext({
      service: "India Tour",
      destination: selectedDestination?.name || ""
    });
    setEnquiryOpen(true);
  };

  const renderDestinationCards = (places: typeof destinationsData.northIndia) => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {places.map((destination, index) => (
        <Card 
          key={index} 
          className="overflow-hidden hover:shadow-xl transition-all duration-300 group cursor-pointer"
          onClick={() => handleDestinationClick(destination)}
        >
          <div className="relative h-56">
            <img 
              src={destination.image} 
              alt={destination.name}
              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-4">
              <h3 className="text-xl font-bold text-white mb-1">{destination.name}</h3>
              <p className="text-sm text-white/90">{destination.description}</p>
            </div>
            <div className="absolute top-4 left-4">
              <MapPin className="w-6 h-6 text-white drop-shadow-lg" />
            </div>
          </div>
        </Card>
      ))}
    </div>
  );

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[400px] flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${indiaToursImage})` }}
        />
        <div className="absolute inset-0 hero-overlay" />
        <div className="relative z-10 text-center text-white max-w-4xl mx-auto px-4">
          <h1 className="text-5xl md:text-6xl font-bold mb-4">India Tour Destinations</h1>
          <p className="text-xl md:text-2xl">Discover the Incredible Diversity of India</p>
        </div>
      </section>

      {/* Tours Section */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-foreground mb-4">Explore Destinations by Region</h2>
            <p className="text-lg text-muted-foreground">Click on any destination to learn more and plan your journey</p>
          </div>

          <Tabs defaultValue="north" className="w-full">
            <TabsList className="grid w-full grid-cols-2 md:grid-cols-3 lg:grid-cols-6 mb-8">
              <TabsTrigger value="north">North India</TabsTrigger>
              <TabsTrigger value="south">South India</TabsTrigger>
              <TabsTrigger value="west">West India</TabsTrigger>
              <TabsTrigger value="east">East India</TabsTrigger>
              <TabsTrigger value="northeast">Northeast</TabsTrigger>
              <TabsTrigger value="honeymoon">Honeymoon</TabsTrigger>
            </TabsList>

            <TabsContent value="north">
              {renderDestinationCards(destinationsData.northIndia)}
            </TabsContent>

            <TabsContent value="south">
              {renderDestinationCards(destinationsData.southIndia)}
            </TabsContent>

            <TabsContent value="west">
              {renderDestinationCards(destinationsData.westIndia || destinationsData.northIndia)}
            </TabsContent>

            <TabsContent value="east">
              {renderDestinationCards(destinationsData.eastIndia || destinationsData.northIndia)}
            </TabsContent>

            <TabsContent value="northeast">
              {renderDestinationCards(destinationsData.northeastIndia || destinationsData.northIndia)}
            </TabsContent>

            <TabsContent value="honeymoon">
              {renderDestinationCards(destinationsData.honeymoon || destinationsData.northIndia)}
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 bg-primary text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Explore India?</h2>
          <p className="text-xl mb-8 opacity-90">
            Contact us to plan your perfect India tour to any of these amazing destinations
          </p>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-8">
            <div className="flex items-center space-x-3">
              <Phone className="w-6 h-6" />
              <span className="text-lg">+91 99948-51869</span>
            </div>
            <div className="flex items-center space-x-3">
              <Mail className="w-6 h-6" />
              <span className="text-lg">trichy@vrholidays.co.in</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="btn-hero text-lg px-8 py-4"
              onClick={() => {
                setEnquiryContext({ service: "India Tour - Plan Your Trip", destination: "" });
                setEnquiryOpen(true);
              }}
            >
              Plan Your Trip
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="btn-outline-hero text-lg px-8 py-4"
              onClick={() => {
                setEnquiryContext({ service: "India Tour - Custom Itinerary", destination: "" });
                setEnquiryOpen(true);
              }}
            >
              Custom Itinerary
            </Button>
          </div>
        </div>
      </section>

      <DestinationDetailsDialog
        open={detailsOpen}
        onOpenChange={setDetailsOpen}
        destination={selectedDestination}
        onEnquireClick={handleEnquireFromDetails}
      />

      <EnquiryDialog
        open={enquiryOpen}
        onOpenChange={setEnquiryOpen}
        service={enquiryContext.service}
        destination={enquiryContext.destination}
      />
    </div>
  );
};

export default IndiaToursPage;
