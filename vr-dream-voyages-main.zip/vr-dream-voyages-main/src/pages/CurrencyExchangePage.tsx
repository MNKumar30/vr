import ServiceTemplate from "./ServiceTemplate";
import currencyExchangeImage from "@/assets/currency-exchange.jpg";

const CurrencyExchangePage = () => {
  const services = [
    {
      title: "Foreign Currency Exchange",
      description: "Get the best rates for all major currencies with instant exchange services.",
      features: ["Competitive Exchange Rates", "All Major Currencies", "Instant Service", "Secure Transactions"],
      price: "Best Rates Guaranteed"
    },
    {
      title: "Forex Cards",
      description: "Pre-paid travel cards loaded with foreign currency for safe and convenient travel.",
      features: ["Multi-currency Cards", "Global Acceptance", "PIN Protection", "Online Tracking"],
      price: "Starting ₹500"
    },
    {
      title: "Traveler's Cheques",
      description: "Safe and secure way to carry money abroad with global acceptance.",
      features: ["Global Acceptance", "Replacement if Lost", "No Expiry Date", "Multiple Denominations"],
      price: "1% Service Charge"
    }
  ];

  return (
    <ServiceTemplate
      title="Currency Exchange"
      description="Best Rates for All Your Foreign Exchange Needs"
      heroImage={currencyExchangeImage}
      services={services}
      ctaTitle="Need Foreign Currency?"
      ctaDescription="Get the best exchange rates and reliable service for all your foreign currency needs"
      primaryButtonText="Exchange Currency"
      secondaryButtonText="Check Rates"
    />
  );
};

export default CurrencyExchangePage;