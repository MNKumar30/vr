import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "react-router-dom";
import EnquiryDialog from "@/components/EnquiryDialog";
import { 
  MapPin, 
  Globe, 
  GraduationCap, 
  DollarSign, 
  Send, 
  Plane, 
  FileText, 
  CreditCard,
  Phone,
  Mail,
  Star,
  CheckCircle
} from "lucide-react";

// Import images
import heroImage from "@/assets/hero-travel.jpg";
import indiaToursImage from "@/assets/india-tours.jpg";
import internationalToursImage from "@/assets/international-tours.jpg";
import studyAbroadImage from "@/assets/study-abroad.jpg";
import currencyExchangeImage from "@/assets/currency-exchange.jpg";
import moneyTransferImage from "@/assets/money-transfer.jpg";
import airTicketImage from "@/assets/air-ticket.jpg";
import visaAssistanceImage from "@/assets/visa-assistance.jpg";

const HomePage = () => {
  const [enquiryOpen, setEnquiryOpen] = useState(false);

  const services = [
    {
      title: "India Tour Packages",
      description: "Explore incredible India with our curated tour packages featuring iconic destinations, cultural experiences, and comfortable accommodations.",
      icon: MapPin,
      image: indiaToursImage,
      path: "/india-tours",
      highlights: ["Golden Triangle Tours", "Kerala Backwaters", "Rajasthan Heritage", "Goa Beach Packages"]
    },
    {
      title: "International Tour Packages",
      description: "Discover the world with our international tour packages to exotic destinations across continents with expert guides.",
      icon: Globe,
      image: internationalToursImage,
      path: "/international-tours",
      highlights: ["Europe Tours", "Southeast Asia", "Middle East", "Americas"]
    },
    {
      title: "Study Abroad",
      description: "Complete guidance for studying abroad including university selection, application process, and visa assistance.",
      icon: GraduationCap,
      image: studyAbroadImage,
      path: "/study-abroad",
      highlights: ["University Selection", "Application Support", "Scholarship Guidance", "Pre-departure Briefing"]
    },
    {
      title: "Air Ticket Booking",
      description: "Book domestic and international flights at the best prices with flexible booking options and 24/7 support.",
      icon: Plane,
      image: airTicketImage,
      path: "/air-ticket",
      highlights: ["Best Prices", "All Airlines", "Flexible Booking", "24/7 Support"]
    },
    {
      title: "Visa Assistance",
      description: "Complete visa assistance for all countries with document preparation, application filing, and tracking services.",
      icon: FileText,
      image: visaAssistanceImage,
      path: "/visa-assistance",
      highlights: ["All Countries", "Document Support", "Application Tracking", "Expert Guidance"]
    },
    {
      title: "Passport Appointment",
      description: "Hassle-free passport appointment booking and renewal services with complete documentation support.",
      icon: CreditCard,
      image: visaAssistanceImage,
      path: "/passport-appointment",
      highlights: ["Easy Booking", "Renewal Services", "Document Help", "Quick Processing"]
    }
  ];

  const testimonials = [
    {
      name: "Priya Sharma",
      location: "Mumbai",
      rating: 5,
      comment: "Excellent service for our Kashmir trip. Everything was perfectly organized and the team was very supportive."
    },
    {
      name: "Rajesh Kumar",
      location: "Delhi",
      rating: 5,
      comment: "Got my student visa for Canada with their help. Professional service and great guidance throughout."
    },
    {
      name: "Anita Patel",
      location: "Ahmedabad",
      rating: 5,
      comment: "Best rates for currency exchange and very quick service. Highly recommended for international travel."
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${heroImage})` }}
        />
        <div className="absolute inset-0 hero-overlay" />
        
        <div className="relative z-10 text-center text-white max-w-4xl mx-auto px-4">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 animate-fade-in">
            VR Holidays & Consultancy
          </h1>
          <p className="text-2xl md:text-3xl mb-4 animate-slide-up gradient-text font-semibold">
            Your Dream Our Service
          </p>
          <p className="text-lg md:text-xl mb-8 text-gray-200 animate-slide-up">
            Explore the world with our comprehensive travel and consultancy services. 
            From dream vacations to study abroad programs, we make it all possible.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-bounce-in">
            <Link to="/india-tours">
              <Button size="lg" className="btn-hero text-lg px-8 py-4">
                Explore Services
              </Button>
            </Link>
            <Link to="/contact">
              <Button size="lg" variant="outline" className="btn-outline-hero text-lg px-8 py-4">
                Contact Us
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              Our Services
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Comprehensive travel and consultancy services designed to fulfill all your travel dreams and professional aspirations.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <Card key={service.path} className="service-card group cursor-pointer">
                <Link to={service.path} className="block">
                  <div className="relative h-48 overflow-hidden rounded-t-lg">
                    <img 
                      src={service.image} 
                      alt={service.title}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors" />
                    <div className="absolute top-4 left-4">
                      <service.icon className="w-8 h-8 text-white" />
                    </div>
                  </div>
                  <CardContent className="p-6">
                    <h3 className="text-xl font-bold text-foreground mb-3 group-hover:text-accent transition-colors">
                      {service.title}
                    </h3>
                    <p className="text-muted-foreground mb-4 text-sm leading-relaxed">
                      {service.description}
                    </p>
                    <div className="space-y-2">
                      {service.highlights.slice(0, 2).map((highlight, i) => (
                        <div key={i} className="flex items-center text-sm text-muted-foreground">
                          <CheckCircle className="w-4 h-4 text-accent mr-2 flex-shrink-0" />
                          <span>{highlight}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Link>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-secondary/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              Why Choose VR Holidays?
            </h2>
            <p className="text-xl text-muted-foreground">
              Experience the difference with our personalized service and expertise
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-accent to-accent-glow rounded-full flex items-center justify-center mx-auto mb-6">
                <Star className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-4">Expert Guidance</h3>
              <p className="text-muted-foreground">
                Our experienced team provides personalized assistance for all your travel and consultancy needs.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-primary to-primary-light rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-4">Trusted Service</h3>
              <p className="text-muted-foreground">
                Years of experience and thousands of satisfied customers make us your reliable travel partner.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-success to-success/80 rounded-full flex items-center justify-center mx-auto mb-6">
                <Phone className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-4">24/7 Support</h3>
              <p className="text-muted-foreground">
                Round-the-clock customer support ensures you're never alone during your journey.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              What Our Customers Say
            </h2>
            <p className="text-xl text-muted-foreground">
              Real experiences from our valued customers
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="p-6">
                <CardContent className="p-0">
                  <div className="flex items-center mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-accent fill-current" />
                    ))}
                  </div>
                  <p className="text-muted-foreground mb-4 italic">
                    "{testimonial.comment}"
                  </p>
                  <div>
                    <p className="font-semibold text-foreground">{testimonial.name}</p>
                    <p className="text-sm text-muted-foreground">{testimonial.location}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-primary text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Ready to Start Your Journey?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Contact us today and let us help you plan your perfect trip or achieve your dreams abroad.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-8 justify-center items-center mb-8">
            <div className="flex items-center space-x-3">
              <Phone className="w-6 h-6" />
              <span className="text-lg">+91 99948-51869</span>
            </div>
            <div className="flex items-center space-x-3">
              <Mail className="w-6 h-6" />
              <span className="text-lg">trichy@vrholidays.co.in</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="btn-hero text-lg px-8 py-4"
              onClick={() => setEnquiryOpen(true)}
            >
              Get Started Today
            </Button>
            <Link to="/india-tours">
              <Button size="lg" variant="outline" className="btn-outline-hero text-lg px-8 py-4">
                View Our Services
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <EnquiryDialog
        open={enquiryOpen}
        onOpenChange={setEnquiryOpen}
        service="General Enquiry"
      />
    </div>
  );
};

export default HomePage;