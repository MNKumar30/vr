import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { MapPin, Star } from "lucide-react";

interface Attraction {
  name: string;
  description: string;
}

interface DestinationDetailsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  destination: {
    name: string;
    image: string;
    description: string;
    attractions: Attraction[];
  } | null;
  onEnquireClick: () => void;
}

const DestinationDetailsDialog = ({ 
  open, 
  onOpenChange, 
  destination,
  onEnquireClick 
}: DestinationDetailsDialogProps) => {
  if (!destination) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">{destination.name}</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="relative h-64 rounded-lg overflow-hidden">
            <img 
              src={destination.image} 
              alt={destination.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            <div className="absolute bottom-4 left-4 text-white">
              <p className="text-lg">{destination.description}</p>
            </div>
          </div>

          <div>
            <h3 className="text-xl font-bold text-foreground mb-4 flex items-center">
              <Star className="w-5 h-5 mr-2 text-accent" />
              Famous Places & Attractions
            </h3>
            <div className="space-y-3">
              {destination.attractions.map((attraction, index) => (
                <div 
                  key={index} 
                  className="flex items-start space-x-3 p-3 rounded-lg bg-secondary/20 hover:bg-secondary/30 transition-colors"
                >
                  <MapPin className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-semibold text-foreground">{attraction.name}</h4>
                    <p className="text-sm text-muted-foreground">{attraction.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <Button 
            className="btn-hero w-full text-lg" 
            size="lg"
            onClick={onEnquireClick}
          >
            Book This Destination
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default DestinationDetailsDialog;
