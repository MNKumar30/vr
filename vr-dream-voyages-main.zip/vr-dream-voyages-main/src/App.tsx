import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navigation from "./components/Navigation";
import HomePage from "./pages/HomePage";
import IndiaToursPage from "./pages/IndiaToursPage";
import InternationalToursPage from "./pages/InternationalToursPage";
import HoneymoonToursPage from "./pages/HoneymoonToursPage";
import StudyAbroadPage from "./pages/StudyAbroadPage";
import AirTicketPage from "./pages/AirTicketPage";
import VisaAssistancePage from "./pages/VisaAssistancePage";
import PassportAppointmentPage from "./pages/PassportAppointmentPage";
import ContactPage from "./pages/ContactPage";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Navigation />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/india-tours" element={<IndiaToursPage />} />
          <Route path="/international-tours" element={<InternationalToursPage />} />
          <Route path="/honeymoon-tours" element={<HoneymoonToursPage />} />
          <Route path="/study-abroad" element={<StudyAbroadPage />} />
          <Route path="/air-ticket" element={<AirTicketPage />} />
          <Route path="/visa-assistance" element={<VisaAssistancePage />} />
          <Route path="/passport-appointment" element={<PassportAppointmentPage />} />
          <Route path="/contact" element={<ContactPage />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
