import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Menu, X, Phone, Mail } from "lucide-react";

const Navigation = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const services = [
    { name: "India Tour Packages", path: "/india-tours" },
    { name: "International Tours", path: "/international-tours" },
    { name: "Study Abroad", path: "/study-abroad" },
    { name: "Currency Exchange", path: "/currency-exchange" },
    { name: "Send Money Abroad", path: "/money-transfer" },
    { name: "Air Ticket", path: "/air-ticket" },
    { name: "Visa Assistant", path: "/visa-assistance" },
    { name: "Passport Appointment", path: "/passport-appointment" }
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="bg-background border-b border-border sticky top-0 z-50 backdrop-blur-sm bg-background/95">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-br from-primary to-primary-light rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-xl">VR</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground">VR Holidays & Consultancy</h1>
              <p className="text-sm text-muted-foreground">Your Dream Our Service</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-8">
            <Link 
              to="/" 
              className={`text-sm font-medium transition-colors hover:text-accent ${
                isActive('/') ? 'text-accent' : 'text-foreground'
              }`}
            >
              Home
            </Link>
            
            <div className="relative group">
              <button className="text-sm font-medium text-foreground hover:text-accent transition-colors">
                Services
              </button>
              
              {/* Dropdown Menu */}
              <div className="absolute top-full left-0 mt-2 w-64 bg-card border border-border rounded-lg shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-50">
                <div className="p-2">
                  {services.map((service) => (
                    <Link
                      key={service.path}
                      to={service.path}
                      className={`block px-4 py-2 text-sm rounded-md transition-colors hover:bg-accent hover:text-accent-foreground ${
                        isActive(service.path) ? 'bg-accent text-accent-foreground' : 'text-foreground'
                      }`}
                    >
                      {service.name}
                    </Link>
                  ))}
                </div>
              </div>
            </div>

            <Link to="/contact" className="text-sm font-medium text-foreground hover:text-accent transition-colors">
              Contact
            </Link>

            <div className="flex items-center space-x-4">
              <Button variant="outline" size="sm">
                Login
              </Button>
              <Button size="sm" className="btn-hero">
                Sign Up
              </Button>
            </div>
          </div>

          {/* Contact Info */}
          <div className="hidden md:flex lg:hidden items-center space-x-4 text-sm text-muted-foreground">
            <div className="flex items-center space-x-1">
              <Phone className="w-4 h-4" />
              <span>+91 99948-51869</span>
            </div>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="lg:hidden p-2 text-foreground hover:text-accent transition-colors"
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="lg:hidden border-t border-border">
            <div className="py-4 space-y-4">
              <Link 
                to="/" 
                onClick={() => setIsMenuOpen(false)}
                className={`block px-4 py-2 text-sm font-medium transition-colors hover:text-accent ${
                  isActive('/') ? 'text-accent' : 'text-foreground'
                }`}
              >
                Home
              </Link>
              
              <div className="px-4">
                <p className="text-sm font-medium text-foreground mb-2">Services</p>
                <div className="pl-4 space-y-2">
                  {services.map((service) => (
                    <Link
                      key={service.path}
                      to={service.path}
                      onClick={() => setIsMenuOpen(false)}
                      className={`block py-1 text-sm transition-colors hover:text-accent ${
                        isActive(service.path) ? 'text-accent' : 'text-muted-foreground'
                      }`}
                    >
                      {service.name}
                    </Link>
                  ))}
                </div>
              </div>

              <Link 
                to="/contact" 
                onClick={() => setIsMenuOpen(false)}
                className="block px-4 py-2 text-sm font-medium text-foreground hover:text-accent transition-colors"
              >
                Contact
              </Link>

              <div className="px-4 pt-4 border-t border-border">
                <div className="flex flex-col space-y-3">
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                    <Phone className="w-4 h-4" />
                    <span>+91 99948-51869</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                    <Mail className="w-4 h-4" />
                    <span>vrholidaysandconsultancy@gmail.com</span>
                  </div>
                  <div className="flex space-x-2 pt-2">
                    <Button variant="outline" size="sm" className="flex-1">
                      Login
                    </Button>
                    <Button size="sm" className="btn-hero flex-1">
                      Sign Up
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navigation;