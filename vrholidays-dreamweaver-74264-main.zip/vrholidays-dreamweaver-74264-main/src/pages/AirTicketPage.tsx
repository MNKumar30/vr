import ServiceTemplate from "./ServiceTemplate";
import airTicketImage from "@/assets/air-ticket.jpg";

const AirTicketPage = () => {
  const services = [
    {
      title: "Domestic Flight Booking",
      description: "Book domestic flights at the best prices with all major Indian airlines.",
      features: ["All Airlines", "Best Prices", "Instant Confirmation", "Easy Cancellation"],
      price: "Starting ₹2,500"
    },
    {
      title: "International Flight Booking",
      description: "International flight tickets to destinations worldwide with flexible options.",
      features: ["Global Destinations", "Multiple Airlines", "Flexible Dates", "Group Bookings"],
      price: "Starting ₹25,000"
    },
    {
      title: "Corporate Travel",
      description: "Specialized corporate travel services for business trips and group bookings.",
      features: ["Corporate Rates", "24/7 Support", "Travel Management", "Expense Reporting"],
      price: "Custom Pricing"
    }
  ];

  return (
    <ServiceTemplate
      title="Air Ticket Booking"
      description="Book Flights at the Best Prices with Expert Support"
      heroImage={airTicketImage}
      services={services}
      ctaTitle="Ready to Fly?"
      ctaDescription="Book your domestic or international flights with us and enjoy competitive prices and excellent service"
      primaryButtonText="Book Flights"
      secondaryButtonText="Compare Prices"
    />
  );
};

export default AirTicketPage;