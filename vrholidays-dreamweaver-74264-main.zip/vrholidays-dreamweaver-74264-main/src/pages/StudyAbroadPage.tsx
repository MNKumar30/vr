import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  GraduationCap, 
  BookOpen, 
  Users, 
  Star, 
  Phone, 
  Mail,
  FileText,
  Award,
  Globe,
  CheckCircle
} from "lucide-react";
import studyAbroadImage from "@/assets/study-abroad.jpg";

const StudyAbroadPage = () => {
  const destinations = [
    {
      id: 1,
      country: "Canada",
      universities: ["University of Toronto", "McGill University", "UBC"],
      programs: "Engineering, Business, Medicine, IT",
      avgCost: "CAD 25,000-35,000/year",
      workRights: "20 hrs/week during studies",
      rating: 4.9,
      highlights: ["High Quality Education", "Work Opportunities", "PR Pathway", "Multicultural"],
      image: studyAbroadImage
    },
    {
      id: 2,
      country: "Australia",
      universities: ["University of Melbourne", "ANU", "University of Sydney"],
      programs: "Business, Engineering, Healthcare, Arts",
      avgCost: "AUD 30,000-45,000/year",
      workRights: "20 hrs/week during studies",
      rating: 4.8,
      highlights: ["World-class Universities", "Beautiful Country", "Strong Economy", "Easy Visa"],
      image: studyAbroadImage
    },
    {
      id: 3,
      country: "United Kingdom",
      universities: ["Oxford", "Cambridge", "Imperial College"],
      programs: "All Fields Available",
      avgCost: "£15,000-35,000/year",
      workRights: "20 hrs/week during studies",
      rating: 4.9,
      highlights: ["Historic Universities", "Short Duration", "Research Excellence", "Global Recognition"],
      image: studyAbroadImage
    },
    {
      id: 4,
      country: "United States",
      universities: ["Harvard", "MIT", "Stanford"],
      programs: "Technology, Business, Medicine, Research",
      avgCost: "USD 30,000-60,000/year",
      workRights: "On-campus work allowed",
      rating: 5.0,
      highlights: ["Top Rankings", "Innovation Hub", "Scholarships", "Career Opportunities"],
      image: studyAbroadImage
    },
    {
      id: 5,
      country: "Germany",
      universities: ["TU Munich", "Heidelberg", "RWTH Aachen"],
      programs: "Engineering, Technology, Sciences",
      avgCost: "€500-3,000/year",
      workRights: "120 full days/year",
      rating: 4.7,
      highlights: ["Low Tuition Fees", "Strong Economy", "Engineering Excellence", "Post-study Work"],
      image: studyAbroadImage
    },
    {
      id: 6,
      country: "New Zealand",
      universities: ["University of Auckland", "Otago", "Victoria"],
      programs: "Agriculture, Tourism, IT, Healthcare",
      avgCost: "NZD 22,000-32,000/year",
      workRights: "20 hrs/week during studies",
      rating: 4.6,
      highlights: ["Safe Environment", "Natural Beauty", "Quality Education", "Friendly People"],
      image: studyAbroadImage
    }
  ];

  const services = [
    {
      title: "University Selection",
      description: "Expert guidance to choose the right university and program based on your profile and career goals.",
      icon: BookOpen
    },
    {
      title: "Application Support",
      description: "Complete assistance with application forms, essays, and documentation for multiple universities.",
      icon: FileText
    },
    {
      title: "Scholarship Guidance",
      description: "Help you find and apply for scholarships, grants, and financial aid opportunities.",
      icon: Award
    },
    {
      title: "Visa Assistance",
      description: "Complete visa application support including document preparation and interview coaching.",
      icon: Globe
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-96 flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${studyAbroadImage})` }}
        />
        <div className="absolute inset-0 hero-overlay" />
        
        <div className="relative z-10 text-center text-white max-w-4xl mx-auto px-4">
          <h1 className="text-4xl md:text-6xl font-bold mb-4 animate-fade-in">
            Study Abroad Programs
          </h1>
          <p className="text-xl md:text-2xl animate-slide-up">
            Your Gateway to World-Class Education
          </p>
        </div>
      </section>

      {/* Study Destinations */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              Top Study Destinations
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Explore world-renowned universities and educational systems across the globe. Our expert counselors will guide you to the perfect destination for your academic journey.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {destinations.map((destination) => (
              <Card key={destination.id} className="service-card group overflow-hidden">
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={destination.image} 
                    alt={destination.country}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors" />
                  <Badge className="absolute top-4 left-4 bg-accent text-accent-foreground">
                    {destination.country}
                  </Badge>
                  <div className="absolute top-4 right-4 flex items-center space-x-1 bg-black/50 text-white px-2 py-1 rounded">
                    <Star className="w-4 h-4 fill-current text-yellow-400" />
                    <span className="text-sm">{destination.rating}</span>
                  </div>
                </div>
                
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold text-foreground mb-2 group-hover:text-accent transition-colors">
                    Study in {destination.country}
                  </h3>
                  
                  <div className="space-y-2 mb-4 text-sm">
                    <div>
                      <span className="font-semibold text-foreground">Top Universities: </span>
                      <span className="text-muted-foreground">{destination.universities.join(", ")}</span>
                    </div>
                    <div>
                      <span className="font-semibold text-foreground">Popular Programs: </span>
                      <span className="text-muted-foreground">{destination.programs}</span>
                    </div>
                    <div>
                      <span className="font-semibold text-foreground">Average Cost: </span>
                      <span className="text-muted-foreground">{destination.avgCost}</span>
                    </div>
                    <div>
                      <span className="font-semibold text-foreground">Work Rights: </span>
                      <span className="text-muted-foreground">{destination.workRights}</span>
                    </div>
                  </div>

                  <div className="space-y-2 mb-4">
                    {destination.highlights.slice(0, 2).map((highlight, i) => (
                      <div key={i} className="flex items-center text-sm text-muted-foreground">
                        <CheckCircle className="w-4 h-4 text-accent mr-2 flex-shrink-0" />
                        <span>{highlight}</span>
                      </div>
                    ))}
                  </div>

                  <Button className="btn-hero w-full">
                    Get Counseling
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Services Section */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-accent to-accent-glow rounded-full flex items-center justify-center mx-auto mb-4">
                  <service.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-bold text-foreground mb-2">{service.title}</h3>
                <p className="text-muted-foreground text-sm">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Consultation Section */}
      <section className="py-20 bg-primary text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Start Your Study Abroad Journey
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Book a free consultation with our education experts and get personalized guidance for your study abroad plans
          </p>
          
          <div className="flex flex-col sm:flex-row gap-8 justify-center items-center mb-8">
            <div className="flex items-center space-x-3">
              <Phone className="w-6 h-6" />
              <span className="text-lg">+91 99948-51869</span>
            </div>
            <div className="flex items-center space-x-3">
              <Mail className="w-6 h-6" />
              <span className="text-lg">vrholidaysandconsultancy@gmail.com</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="btn-hero text-lg px-8 py-4">
              <GraduationCap className="w-5 h-5 mr-2" />
              Free Consultation
            </Button>
            <Button size="lg" variant="outline" className="btn-outline-hero text-lg px-8 py-4">
              <Users className="w-5 h-5 mr-2" />
              Book Appointment
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default StudyAbroadPage;