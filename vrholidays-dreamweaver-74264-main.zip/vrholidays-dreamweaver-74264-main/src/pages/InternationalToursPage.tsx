import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  MapPin, 
  Calendar, 
  Users, 
  Star, 
  Phone, 
  Mail,
  Globe,
  Plane
} from "lucide-react";
import internationalToursImage from "@/assets/international-tours.jpg";

const InternationalToursPage = () => {
  const tourPackages = [
    {
      id: 1,
      name: "Europe Grand Tour",
      destinations: ["Paris", "Rome", "Barcelona", "Amsterdam"],
      duration: "12 Days / 11 Nights",
      price: "₹1,80,000",
      rating: 4.9,
      highlights: ["Eiffel Tower", "Colosseum", "Sagrada Familia", "Canal Cruise"],
      image: internationalToursImage
    },
    {
      id: 2,
      name: "Southeast Asia Explorer",
      destinations: ["Thailand", "Singapore", "Malaysia", "Indonesia"],
      duration: "10 Days / 9 Nights", 
      price: "₹1,20,000",
      rating: 4.8,
      highlights: ["Temples", "Street Food", "Beaches", "Cultural Shows"],
      image: internationalToursImage
    },
    {
      id: 3,
      name: "Dubai & Abu Dhabi",
      destinations: ["Dubai", "Abu Dhabi"],
      duration: "6 Days / 5 Nights",
      price: "₹85,000",
      rating: 4.7,
      highlights: ["Burj Khalifa", "Desert Safari", "Luxury Shopping", "Grand Mosque"],
      image: internationalToursImage
    },
    {
      id: 4,
      name: "Japan Cherry Blossom",
      destinations: ["Tokyo", "Kyoto", "Osaka"],
      duration: "8 Days / 7 Nights",
      price: "₹1,50,000",
      rating: 5.0,
      highlights: ["Cherry Blossoms", "Temples", "Bullet Train", "Traditional Culture"],
      image: internationalToursImage
    },
    {
      id: 5,
      name: "USA East Coast",
      destinations: ["New York", "Washington DC", "Boston"],
      duration: "9 Days / 8 Nights",
      price: "₹2,20,000",
      rating: 4.8,
      highlights: ["Statue of Liberty", "White House", "Harvard University", "Times Square"],
      image: internationalToursImage
    },
    {
      id: 6,
      name: "Australia Adventure",
      destinations: ["Sydney", "Melbourne", "Gold Coast"],
      duration: "11 Days / 10 Nights",
      price: "₹2,50,000",
      rating: 4.9,
      highlights: ["Opera House", "Great Ocean Road", "Theme Parks", "Wildlife Parks"],
      image: internationalToursImage
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-96 flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${internationalToursImage})` }}
        />
        <div className="absolute inset-0 hero-overlay" />
        
        <div className="relative z-10 text-center text-white max-w-4xl mx-auto px-4">
          <h1 className="text-4xl md:text-6xl font-bold mb-4 animate-fade-in">
            International Tour Packages
          </h1>
          <p className="text-xl md:text-2xl animate-slide-up">
            Explore the World's Most Amazing Destinations
          </p>
        </div>
      </section>

      {/* Tour Packages Grid */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              Popular International Tours
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              From European classics to exotic Asian adventures, discover the world's most sought-after destinations with our expertly crafted international tour packages.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {tourPackages.map((tour) => (
              <Card key={tour.id} className="service-card group overflow-hidden">
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={tour.image} 
                    alt={tour.name}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors" />
                  <Badge className="absolute top-4 left-4 bg-accent text-accent-foreground">
                    {tour.duration}
                  </Badge>
                  <div className="absolute top-4 right-4 flex items-center space-x-1 bg-black/50 text-white px-2 py-1 rounded">
                    <Star className="w-4 h-4 fill-current text-yellow-400" />
                    <span className="text-sm">{tour.rating}</span>
                  </div>
                </div>
                
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold text-foreground mb-2 group-hover:text-accent transition-colors">
                    {tour.name}
                  </h3>
                  
                  <div className="flex items-center text-muted-foreground mb-3">
                    <MapPin className="w-4 h-4 mr-1" />
                    <span className="text-sm">{tour.destinations.join(" • ")}</span>
                  </div>

                  <div className="space-y-2 mb-4">
                    {tour.highlights.slice(0, 3).map((highlight, i) => (
                      <div key={i} className="flex items-center text-sm text-muted-foreground">
                        <div className="w-2 h-2 bg-accent rounded-full mr-3 flex-shrink-0" />
                        <span>{highlight}</span>
                      </div>
                    ))}
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t border-border">
                    <div>
                      <span className="text-2xl font-bold text-accent">{tour.price}</span>
                      <span className="text-sm text-muted-foreground ml-1">per person</span>
                    </div>
                    <Button className="btn-hero">
                      Book Now
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Booking Section */}
      <section className="py-20 bg-primary text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Ready to Explore the World?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Let our travel experts help you plan your dream international vacation
          </p>
          
          <div className="flex flex-col sm:flex-row gap-8 justify-center items-center mb-8">
            <div className="flex items-center space-x-3">
              <Phone className="w-6 h-6" />
              <span className="text-lg">+91 99948-51869</span>
            </div>
            <div className="flex items-center space-x-3">
              <Mail className="w-6 h-6" />
              <span className="text-lg">vrholidaysandconsultancy@gmail.com</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="btn-hero text-lg px-8 py-4">
              <Plane className="w-5 h-5 mr-2" />
              Book International Tour
            </Button>
            <Button size="lg" variant="outline" className="btn-outline-hero text-lg px-8 py-4">
              <Globe className="w-5 h-5 mr-2" />
              Custom Itinerary
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default InternationalToursPage;