import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { 
  Phone, 
  Mail, 
  MapPin, 
  Clock,
  Send,
  MessageCircle
} from "lucide-react";

const ContactPage = () => {
  return (
    <div className="min-h-screen py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-4">
            Contact Us
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Get in touch with our travel experts. We're here to help you plan your perfect journey or answer any questions you may have.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <div className="space-y-8">
            <Card className="service-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3 text-2xl">
                  <Phone className="w-6 h-6 text-accent" />
                  <span>Call Us</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-lg font-semibold text-foreground mb-2">+91 99948-51869</p>
                <p className="text-muted-foreground">
                  Available Monday to Saturday, 10:00 AM to 7:00 PM IST
                </p>
              </CardContent>
            </Card>

            <Card className="service-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3 text-2xl">
                  <Mail className="w-6 h-6 text-accent" />
                  <span>Email Us</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-lg font-semibold text-foreground mb-2">
                  vrholidaysandconsultancy@gmail.com
                </p>
                <p className="text-muted-foreground">
                  We'll respond to your email within 24 hours
                </p>
              </CardContent>
            </Card>

            <Card className="service-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3 text-2xl">
                  <MapPin className="w-6 h-6 text-accent" />
                  <span>Visit Us</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-lg font-semibold text-foreground mb-2">VR Holidays & Consultancy</p>
                <p className="text-muted-foreground mb-4">
                  NO:74/1, Ground Floor, Murugan Complex,<br />
                  Salai Road, Annamalai Nager,<br />
                  Trichy - 620018
                </p>
                <div className="flex items-center space-x-2 text-muted-foreground">
                  <Clock className="w-4 h-4" />
                  <span>Mon-Sat: 10:00 AM - 7:00 PM</span>
                </div>
              </CardContent>
            </Card>

            <div className="bg-accent/10 rounded-lg p-6">
              <h3 className="text-xl font-bold text-foreground mb-3">Why Choose VR Holidays?</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-accent rounded-full mr-3 flex-shrink-0" />
                  <span>Expert travel consultants with years of experience</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-accent rounded-full mr-3 flex-shrink-0" />
                  <span>Personalized service for all your travel needs</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-accent rounded-full mr-3 flex-shrink-0" />
                  <span>24/7 support during your travels</span>
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-accent rounded-full mr-3 flex-shrink-0" />
                  <span>Competitive prices and transparent policies</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Contact Form */}
          <Card className="service-card">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3 text-2xl">
                <MessageCircle className="w-6 h-6 text-accent" />
                <span>Send us a Message</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="firstName">First Name</Label>
                  <Input id="firstName" placeholder="Enter your first name" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName">Last Name</Label>
                  <Input id="lastName" placeholder="Enter your last name" />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input id="email" type="email" placeholder="Enter your email address" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input id="phone" type="tel" placeholder="Enter your phone number" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="service">Service Interested In</Label>
                <select 
                  id="service" 
                  className="w-full px-3 py-2 border border-border rounded-md bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                >
                  <option value="">Select a service</option>
                  <option value="india-tours">India Tour Packages</option>
                  <option value="international-tours">International Tour Packages</option>
                  <option value="study-abroad">Study Abroad</option>
                  <option value="currency-exchange">Currency Exchange</option>
                  <option value="money-transfer">Send Money Abroad</option>
                  <option value="air-ticket">Air Ticket</option>
                  <option value="visa-assistance">Visa Assistant</option>
                  <option value="passport-appointment">Passport Appointment</option>
                </select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="message">Message</Label>
                <Textarea 
                  id="message" 
                  placeholder="Tell us about your travel plans or requirements..."
                  rows={5}
                />
              </div>

              <Button className="btn-hero w-full text-lg">
                <Send className="w-5 h-5 mr-2" />
                Send Message
              </Button>

              <p className="text-sm text-muted-foreground text-center">
                By submitting this form, you agree to our privacy policy and terms of service.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;