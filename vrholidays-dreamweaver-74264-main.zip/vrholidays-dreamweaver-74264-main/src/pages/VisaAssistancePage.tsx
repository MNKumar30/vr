import ServiceTemplate from "./ServiceTemplate";
import visaAssistanceImage from "@/assets/visa-assistance.jpg";

const VisaAssistancePage = () => {
  const services = [
    {
      title: "Tourist Visa",
      description: "Complete assistance for tourist visas to all popular destinations worldwide.",
      features: ["All Countries", "Document Guidance", "Application Support", "Status Tracking"],
      price: "Starting ₹2,000"
    },
    {
      title: "Business Visa",
      description: "Business visa services for corporate travelers and entrepreneurs.",
      features: ["Fast Processing", "Business Documentation", "Invitation Letters", "Multiple Entry"],
      price: "Starting ₹3,500"
    },
    {
      title: "Student Visa",
      description: "Student visa assistance for studying abroad with complete documentation support.",
      features: ["University Liaison", "Document Preparation", "Interview Coaching", "Visa Guidance"],
      price: "Starting ₹5,000"
    },
    {
      title: "Transit Visa",
      description: "Transit visa services for travelers with connecting flights through other countries.",
      features: ["Quick Processing", "Airport Transit", "Multiple Countries", "Same Day Service"],
      price: "Starting ₹1,500"
    }
  ];

  return (
    <ServiceTemplate
      title="Visa Assistance"
      description="Complete Visa Services for All Countries & Purposes"
      heroImage={visaAssistanceImage}
      services={services}
      ctaTitle="Need Visa Assistance?"
      ctaDescription="Let our visa experts handle your visa application process from start to finish"
      primaryButtonText="Apply for Visa"
      secondaryButtonText="Check Requirements"
    />
  );
};

export default VisaAssistancePage;