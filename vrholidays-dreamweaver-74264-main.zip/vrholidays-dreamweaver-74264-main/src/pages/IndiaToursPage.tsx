import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  MapPin, 
  Calendar, 
  Users, 
  Star, 
  Phone, 
  Mail,
  Clock,
  Camera,
  Mountain,
  Building
} from "lucide-react";
import indiaToursImage from "@/assets/india-tours.jpg";

const IndiaToursPage = () => {
  const tourPackages = [
    {
      id: 1,
      name: "Golden Triangle Tour",
      destinations: ["Delhi", "Agra", "Jaipur"],
      duration: "6 Days / 5 Nights",
      price: "₹25,000",
      rating: 4.8,
      highlights: ["Taj Mahal", "Red Fort", "Hawa Mahal", "City Palace"],
      image: indiaToursImage
    },
    {
      id: 2,
      name: "Kerala Backwaters",
      destinations: ["Kochi", "Alleppey", "Kumarakom"],
      duration: "5 Days / 4 Nights", 
      price: "₹30,000",
      rating: 4.9,
      highlights: ["Houseboat Stay", "Spice Gardens", "Beach Resorts", "Ayurvedic Spa"],
      image: indiaToursImage
    },
    {
      id: 3,
      name: "Rajasthan Heritage",
      destinations: ["Jaipur", "Udaipur", "Jodhpur", "Jaisalmer"],
      duration: "8 Days / 7 Nights",
      price: "₹45,000",
      rating: 4.7,
      highlights: ["Desert Safari", "Palace Hotels", "Camel Ride", "Folk Dance"],
      image: indiaToursImage
    },
    {
      id: 4,
      name: "Goa Beach Paradise",
      destinations: ["North Goa", "South Goa"],
      duration: "4 Days / 3 Nights",
      price: "₹20,000",
      rating: 4.6,
      highlights: ["Beach Resorts", "Water Sports", "Nightlife", "Portuguese Heritage"],
      image: indiaToursImage
    },
    {
      id: 5,
      name: "Kashmir Valley",
      destinations: ["Srinagar", "Gulmarg", "Pahalgam"],
      duration: "7 Days / 6 Nights",
      price: "₹40,000",
      rating: 5.0,
      highlights: ["Dal Lake", "Shikara Ride", "Snow Activities", "Mughal Gardens"],
      image: indiaToursImage
    },
    {
      id: 6,
      name: "Himachal Adventure",
      destinations: ["Shimla", "Manali", "Dharamshala"],
      duration: "6 Days / 5 Nights",
      price: "₹35,000",
      rating: 4.8,
      highlights: ["Mountain Trekking", "Adventure Sports", "Hill Stations", "Local Culture"],
      image: indiaToursImage
    }
  ];

  const features = [
    { icon: Users, title: "Expert Local Guides", description: "Experienced guides with deep local knowledge" },
    { icon: Calendar, title: "Flexible Booking", description: "Easy booking with flexible cancellation" },
    { icon: Star, title: "Premium Hotels", description: "Handpicked accommodations for comfort" },
    { icon: Camera, title: "Photo Opportunities", description: "Capture memories at iconic locations" }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-96 flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${indiaToursImage})` }}
        />
        <div className="absolute inset-0 hero-overlay" />
        
        <div className="relative z-10 text-center text-white max-w-4xl mx-auto px-4">
          <h1 className="text-4xl md:text-6xl font-bold mb-4 animate-fade-in">
            India Tour Packages
          </h1>
          <p className="text-xl md:text-2xl animate-slide-up">
            Discover Incredible India with Our Curated Travel Experiences
          </p>
        </div>
      </section>

      {/* Tour Packages Grid */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              Popular India Tours
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              From the majestic Himalayas to tropical beaches, explore India's diverse landscapes and rich culture with our specially designed tour packages.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {tourPackages.map((tour) => (
              <Card key={tour.id} className="service-card group overflow-hidden">
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={tour.image} 
                    alt={tour.name}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors" />
                  <Badge className="absolute top-4 left-4 bg-accent text-accent-foreground">
                    {tour.duration}
                  </Badge>
                  <div className="absolute top-4 right-4 flex items-center space-x-1 bg-black/50 text-white px-2 py-1 rounded">
                    <Star className="w-4 h-4 fill-current text-yellow-400" />
                    <span className="text-sm">{tour.rating}</span>
                  </div>
                </div>
                
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold text-foreground mb-2 group-hover:text-accent transition-colors">
                    {tour.name}
                  </h3>
                  
                  <div className="flex items-center text-muted-foreground mb-3">
                    <MapPin className="w-4 h-4 mr-1" />
                    <span className="text-sm">{tour.destinations.join(" • ")}</span>
                  </div>

                  <div className="space-y-2 mb-4">
                    {tour.highlights.slice(0, 3).map((highlight, i) => (
                      <div key={i} className="flex items-center text-sm text-muted-foreground">
                        <div className="w-2 h-2 bg-accent rounded-full mr-3 flex-shrink-0" />
                        <span>{highlight}</span>
                      </div>
                    ))}
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t border-border">
                    <div>
                      <span className="text-2xl font-bold text-accent">{tour.price}</span>
                      <span className="text-sm text-muted-foreground ml-1">per person</span>
                    </div>
                    <Button className="btn-hero">
                      Book Now
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Features Section */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-accent to-accent-glow rounded-full flex items-center justify-center mx-auto mb-4">
                  <feature.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-bold text-foreground mb-2">{feature.title}</h3>
                <p className="text-muted-foreground text-sm">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Booking Section */}
      <section className="py-20 bg-primary text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Ready to Explore India?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Contact our travel experts to customize your perfect India tour package
          </p>
          
          <div className="flex flex-col sm:flex-row gap-8 justify-center items-center mb-8">
            <div className="flex items-center space-x-3">
              <Phone className="w-6 h-6" />
              <span className="text-lg">+91 99948-51869</span>
            </div>
            <div className="flex items-center space-x-3">
              <Mail className="w-6 h-6" />
              <span className="text-lg">vrholidaysandconsultancy@gmail.com</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="btn-hero text-lg px-8 py-4">
              <Calendar className="w-5 h-5 mr-2" />
              Book Your Tour
            </Button>
            <Button size="lg" variant="outline" className="btn-outline-hero text-lg px-8 py-4">
              <Phone className="w-5 h-5 mr-2" />
              Call for Custom Package
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default IndiaToursPage;